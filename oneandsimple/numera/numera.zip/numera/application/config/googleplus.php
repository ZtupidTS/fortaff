<?php
$config['googleplus']['application_name'] = 'gdrive';
$config['googleplus']['client_id'] = '449354131456.apps.googleusercontent.com';
$config['googleplus']['client_secret'] = '5r2E63D5SvPj4ZAkyGm2VsMk';
$config['googleplus']['redirect_uri'] = 'http://localhost/oneandsimple/user';
$config['googleplus']['api_key'] = 'AIzaSyAGHs-zpYE5q7lSJlgWDIGvf7StUBgORf0';
?>
