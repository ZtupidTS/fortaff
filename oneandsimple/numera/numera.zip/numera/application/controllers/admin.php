<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends MY_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		
		if($this->session->userdata('loggedInAdmin')){
		redirect('admin/dashboard');}
		$data['title']="Admin Login";
		$this->load->library('googleplus');
		$this->load->model('adminmodel');
	
		$this->form_validation->set_rules('username', 'Username', 'required|callback_username_check');
		$this->form_validation->set_rules('password', 'Password', 'required');
		
		if ($this->form_validation->run()==false){
			$this->load->view('admin/index',$data);
		}else{
			//print_r($_POST);die;
			if (isset($_POST) && (!empty($_POST))) {
				$username = $this->input->post('username');
				$password = $this->input->post('password');
				$chkRememberMe = $this->input->post('chk_remember_me');
				$chkRememberMe = $chkRememberMe == 'y' ? true : false;
				
				$data['adminDetail'] = $this->adminmodel->getLoginResult($username, md5($password));
				if($data['adminDetail']){
					if (isset($data['adminDetail']['id'])) {
						$data = array(
							'id' => $data['adminDetail']['id'],
							'admin_name' => $data['adminDetail']['userName'],
							'loggedInAdmin' => TRUE,
							'admin_email' => $data['adminDetail']['userEmail']
						);
						$this->session->set_userdata($data);
					}
					//setting user credential in cookies
					if ($chkRememberMe === true) {
						$this->input->set_cookie('admin_name', $username, '86500', '', '/', '');
						$this->input->set_cookie('admin_pass', $password, '86500', '', '/', '');
					} else if ($chkRememberMe === false) {
						$this->input->set_cookie('admin_name', '', '86500', '', '/', '');
						$this->input->set_cookie('admin_pass', '', '86500', '', '/', '');
					}
					redirect('admin/dashboard');
				}else{
					echo $this->session->set_flashdata('message', '<div class="alert-error">username and password not exsit.</div>');
					$this->load->view('admin/index.php', $data);
				}
			}
			else {
				$this->load->view('admin/', $data);
			}
		}
	}
	
	function username_check($str){
		$this->load->model('adminmodel');
		@$data['users'] = $this->adminmodel->checkUserexist($str);
		if ($str != @$data['users']['userName']) {
			$this->form_validation->set_message('username_check', 'The %s field entered is not correct');
			return FALSE;
		}else {
			return TRUE;
		}
	}
	
	function dashboard(){
		if(!$this->session->userdata('loggedInAdmin'))
		redirect('admin');
		$data['title']='Dashboard';
		$data['menu']='1';
		$this->load->model('adminmodel');
		$data['users']['noofclint']=$this->adminmodel->totolNumberofuser('2',null);
		$data['users']['noofuser']=$this->adminmodel->totolNumberofuser('3', null);
		//print_r($data);
		$this->load->view('admin/dashboard',$data);
		
	}
	function logout(){
		$this->session->sess_destroy();
        	redirect('admin', 'refresh');	
	}
	
	function forgotepassword(){
		$data['title']='Forgote password';
		$this->load->model('adminmodel');
		$this->form_validation->set_rules('email', 'Email', 'required|callback_userEmail_check');
		if ($this->form_validation->run()==false){
			$this->load->view('admin/forgotepassword',$data);
		}else{
			$useremail=$this->input->post('userEmail');				   
			//die($this->form_validation->run());
			$userdetail = $this->adminmodel->checkusremail($useremail);
			$username = $userdetail['userName'];
			$userId = $userdetail['id'];
			$newuserpassword = time();
			$getresult=$this->adminmodel->updatepassword($userId,md5($newuserpassword));
			//die();
			if($getresult)
			{
				//print_r($userdetail);
				$to = $useremail;
				$subject='Forgote password';
				$data='Hello'.$username.',<br/> Your new password is <b>'.$newuserpassword.'</b><br/>Regards <br/>Oneandsimple';	
				/*Call function */
				//send_mail($to,$subject,$data);
				$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://smtp.googlemail.com',
					'smtp_port' => 465,
					'smtp_user' => 'oneandsimple76@gmail.com',
					'smtp_pass' => 'oneandsimple76123456',
					'mailtype'  => 'html',
					'charset'   => 'iso-8859-1'
				    );
				$this->load->library('email',$config);		
				$this->email->from('oneandsimple76@gmail.com', 'oneandsimple');
				$this->email->to($to);
				$this->email->subject($subject);
				$this->email->message( $this->load->view( 'emails/message', $data, true ) );
				$this->email->send();
				$this->session->set_flashdata('message', '<div class="alert-success">New password has been sent on email.</div>');
				
			}else{
				$this->session->set_flashdata('message', '<div class="alert-error">Email is not send, try again!</div>');
			}
			redirect('admin/forgotepassword','refresh');
			//$this->load->view('admin/forgotepassword',$data);
		}
	}
	function userEmail_check($str){
		$this->load->model('adminmodel');
		@$data['users'] = $this->adminmodel->checkusremail($str);
		if ($str != @$data['users']['userEmail']) {
			$this->form_validation->set_message('userEmail_check', 'The %s field you have entered is not correct');
			return FALSE;
		}else{
			return TRUE;
		}
	}
	
	public function changepassword() {
		
		if(!$this->session->userdata('loggedInAdmin'))
		redirect('admin');
		$this->load->model('adminmodel');
		$this->form_validation->set_rules('userPassword', 'password', 'required|callback_currentpwd_check');
		$this->form_validation->set_rules('newuserPassword', 'New Password', 'required|callback_newpassword_check');
		$this->form_validation->set_rules('confirmPassword', 'Confirm Password', 'required');
			
		if ($this->form_validation->run()==false){
			$data['menu']='6';
			$this->load->view('admin/changepassword',$data);
					

		}else{
			$uid=$this->session->userdata('id');
			$getuserDetails=$this->adminmodel->getuserDetail($uid,$roleid='1');
			$username = $getuserDetails['userName'];
			$useremail = $getuserDetails['userEmail'];
			$newuserpwd=$this->input->post('newuserPassword');
			/*update password*/
			$getresult=$this->adminmodel->updatepassword($uid,md5($newuserpwd));
			//die();
			if($getresult)
			{
				//print_r($userdetail);
				$to = $useremail;
				$subject='Change password notification';
				$this->input->post('confirmPassword');
				$data='Hello'.$username.',<br/> Your new password is <b>'.$newuserpwd.'</b><br/>Regards <br/>Oneandsimple';	
				/*Call function */
				//send_mail($to,$subject,$data);
				$config = Array(
					'protocol' => 'smtp',
					'smtp_host' => 'ssl://smtp.googlemail.com',
					'smtp_port' => 465,
					'smtp_user' => 'oneandsimple76@gmail.com',
					'smtp_pass' => 'oneandsimple76123456',
					'mailtype'  => 'html',
					'charset'   => 'iso-8859-1'
				    );
				$this->load->library('email',$config);		
				$this->email->from('oneandsimple76@gmail.com', 'oneandsimple');
				$this->email->to($to);
				$this->email->subject($subject);
				$this->email->message( $this->load->view( 'emails/message', $data, true ) );
				$this->email->send();
				$this->session->set_flashdata('message', '<div class="alert-success">Password has been change successfully. </div>');
			}else{
				$this->session->set_flashdata('message', '<div class="alert-error">Your password is not change, please try again!</div>');
			}
			//echo $this->email->print_debugger();			
			redirect('admin/changepassword','refresh');
			//$this->load->view('admin/changepassword');			
		}		
	}
	function currentpwd_check($str){
		$this->load->model('adminmodel');
		$uid=$this->session->userdata('loggedInAdmin');
		@$data['users'] = $this->adminmodel->checkusrpwdxist(md5($str),$uid);
		//print_r($data['users']);
		if (md5($str) != @$data['users']['userPassword']) {
			$this->form_validation->set_message('currentpwd_check', 'The current %s you have entered is not correct');
			return FALSE;
		}else {
			return TRUE;
		}
	}
	function newpassword_check($str){
		
		if ($str != $this->input->post('confirmPassword')) {
			$this->form_validation->set_message('newpassword_check', 'The %s and confirm password does not match.');
			return FALSE;
		}else {
			return TRUE;
		}
		
	}
	
	
	
	function editprofile()
	{
		$data['title']='My profile';
		$this->load->model('adminmodel');
		if(!$this->session->userdata('loggedInAdmin'))
		redirect('admin');
		$data['menu']='7';
		if($this->session->userdata('loggedInAdmin')){
			$id = $this->session->userdata('id');
			$data['adminDetails'] = $this->adminmodel->getuserDetail($id,$roleid='1');
			$this->load->view('admin/profile',$data);
			
		}
	}
	
	/*Add New user under the client*/
	function adduser($clientId=null,$userId=null)
	{
		$this->load->model('adminmodel');
		$data['menu']='2';
		if($this->session->userdata('loggedInAdmin')){
			$data['userId']=$clientId;
			
			/*Get All Client List*/
			$data['clientlist']=$this->adminmodel->totolNumberofuser('2','client');
			
			/*Get All Defualt Folder list*/
			$data['folders'] = $this->adminmodel->getallfolders(null);

			/*Permission code here */
				$data['results'] = $this->adminmodel->getallpermissions(null);
				//pr($data['results']);
			if($userId){
				$data['title']='Edit user';
				$data['userDetail']=$this->adminmodel->getuserFullDetail($clientId,$roleid='3');
				//pr($data['userDetail']);
				if($data['userDetail']['id']){
					$data['userId']= $data['userDetail']['userId'];
				}
				/*Get only user permission List*/
				$data['userpermissions'] = $this->adminmodel->getuserpermissions($clientId);
				/*Decode Client selected file permissions*/
					if(isset($data['userpermissions']['permissionId']) && !empty($data['userpermissions']['permissionId'])){
						$userpermissionAry = json_decode($data['userpermissions']['permissionId']);
						foreach($userpermissionAry as $ky=>$val)
						{
							   $arraykey[$ky]=$userpermissionAry->$ky;	
						}
						$data['select_usr_permission']=$arraykey;
					}
			
				/*Get only Client Folder selected permission List*/
				$data['folderpermissions_array'] = $this->adminmodel->getclientfolderPermission($clientId);
				if(isset($data['folderpermissions_array']['folderpermissions']) && !empty($data['folderpermissions_array']['folderpermissions'])){
					$folderpermissionAry = json_decode($data['folderpermissions_array']['folderpermissions']);
					foreach($folderpermissionAry as $ky=>$val)
					{
						//if($val=='yes'){
						   $folderarraykey[$ky]=$folderpermissionAry->$ky;	
						//}
					}
					
					$data['select_client_folder_permission']=$folderarraykey;
				}
			}
			//pre($data['select_client_folder_permission']);
			else{
				$data['title']='Add user';
			}
			if ($this->form_validation->run()==false){
				$this->load->view('admin/manageuser',$data);
			}
			
		}else{ redirect('admin/'); }
		
	}
	
	
	public function manageuser($clientId=null,$id=null)
	{
		$data['menu']='2';
		$this->load->model('adminmodel');
		if($this->uri->segment(4) || $this->input->post('id')) /*Get existing client details*/
		{
			$data['title']='Edit User';
		}
		else{ $data['title']='Add User';
			$id='';
		}
		if($this->input->post('btnsubmit'))
		{
			$id = $this->input->post('id');
			$data['userId']=$clientId;
			
			
			if(!$this->input->post('id')){
				$this->form_validation->set_rules('userPassword', 'Password', 'required');
				$this->form_validation->set_rules('userEmail', 'Email', 'required|email|valid_email|is_unique[users.userEmail]');
			}else{
				$this->form_validation->set_rules('userEmail', 'Email', 'required|email|valid_email');					
				}	
			$this->form_validation->set_rules('fname', 'First name', 'required|min_length[3]|max_length[25]');
			$this->form_validation->set_rules('lname', 'Last Name', 'required|min_length[3]|max_length[25]');
			$this->form_validation->set_rules('profession', 'Profession', 'required|min_length[3]|max_length[200]');
			$this->form_validation->set_rules('userPhone', 'Phone', 'required|integer|min_length[10]|max_length[15]');
			
			if ($this->form_validation->run()==false){
				$data['clientId'] = $this->input->post('clientid');		
				if(!$this->input->post('id')){
					$data['userDetail']['userPassword'] = $this->input->post('password');
				}
				$data['userDetail']['userEmail'] = $this->input->post('email');
				$data['userDetail']['userImage'] = $this->input->post('image');
				$data['userDetail']['clientId'] = $this->input->post('clientid');
				$data['userDetail']['fname'] = $this->input->post('fname');
				$data['userDetail']['lname'] = $this->input->post('lname');
				$data['userDetail']['profession'] = $this->input->post('profession');
				$data['upload_error'] = "";
				
				$this->load->view('admin/manageuser',$data);
				//redirect("admin/adduser/$clientId/$id");
				
			}else
			{
				/*Send email to user*/
				$error = $this->adminmodel->saveUser($task='user');
				if($error){
					/*message*/
					/*Send email to user*/
					$this->_sendWelcomeMail($type="user");
					if($error=='add'){$this->session->set_flashdata('message', '<div class="alert-success">User add successfully.</div>');}
					elseif($error=='update'){
						$this->session->set_flashdata('message', '<div class="alert-success">User Updated successfully </div>');
					}
					/*redirect*/		
					if($task=='user'){redirect('admin/users');}
					else {redirect('admin/users');}
				}else{
					$data['users']['userPassword'] = $this->input->post('password');
					$data['users']['userEmail'] = $this->input->post('email');
					$data['users']['userImage'] = $this->input->post('image');
					$data['clientId'] = $this->input->post('clientid');
					$data['users']['fname'] = $this->input->post('clientid');
					$data['users']['fname'] = $this->input->post('fname');
					$data['users']['lname'] = $this->input->post('lname');
					$data['users']['profession'] = $this->input->post('profession');
					$data['upload_error'] = $error['error'];
					$this->session->set_flashdata('message', '<div class="alert-error">User not added, Try Again!.</div>');
					redirect("admin/adduser/$clientId/$id");
				}
			}
		}else{
				redirect("admin/adduser/$clientId");
			}	
	}
	
	
	
	
	/*Save user*/
	function manageadmin($task=null)
	{
		$data['menu']='3';	
		$this->load->model('adminmodel');
		if($this->session->userdata('loggedInAdmin')){		
			$this->form_validation->set_rules('userName', 'User Name', 'required|min_length[5]');
			$this->form_validation->set_rules('userEmail', 'Email', 'required|valid_email');
			$this->form_validation->set_rules('userPhone', 'Phone', 'integer|integer|min_length[10]|max_length[15]');
			$this->form_validation->set_rules('adminFooterTxt', 'Footer text', 'required');
			if ($this->form_validation->run()==false){
				
				//$data['user']['id'] = $this->session->userdata('id');
				$data['user']['userName'] = $this->input->post('userName');
				$data['user']['userEmail'] = $this->input->post('userEmail');
				$data['user']['userPhone'] = $this->input->post('userPhone');
				redirect('admin/editprofile');
				//$this->load->view('admin/profile',$data);
			}else{
				
				$error = $this->adminmodel->saveUser($task='admin');
				if($error=='update'){
					$this->session->set_flashdata('message', '<div class="alert-success">Profile has been updated successfully.</div>');
					redirect('admin/editprofile');
				}else{
					$data['user']['id'] = $this->input->post('id');
					$data['user']['userName'] = $this->input->post('userName');
					$data['user']['userEmail'] = $this->input->post('userEmail');
					$data['user']['userPhone'] = $this->input->post('userPhone');
					if($this->input->post('userImage')){
						$data['user']['userImage'] = $this->input->post('userImage');
					}
					$data['upload_error'] = $error['error'];
					$this->session->set_flashdata('message', '<div class="alert-success">Profile not updated, Try Again!.</div>');
					redirect('admin/editprofile');
				}
			}
		}else{
			redirect('admin');
		}
	}
	
	
	
	/*List of All user under the all client*/
	/*List of All client*/
	function users(){
		$this->load->library("pagination");
		$this->load->model('adminmodel');
		//page title
		 $data['title']='Users';
		$data['menu']='2';
		 //pagination configurations
		 $data['total_row']= $this->adminmodel->getUserlist($uclientid=null,$type='users',null, null);

		 $config['total_rows'] = count($data['total_row']);
		 $config['per_page'] = PER_PAGE_RECORD; /*DEFINE IN CONFIG/CONSTAANT.PHP*/;
		 $config['full_tag_open'] = '<div id="pagination">';
		 $config['full_tag_close'] = '</div>';
		
		 //get all the URI segments for pagination and sorting
		 $segment_array=$this->uri->segment_array();
		 $segment_count=$this->uri->total_segments();
		
		 //for ordering the data items
		 $do_orderby = array_search("orderby",$segment_array);
		
		 //asc and desc sorting
		 $asc = array_search("asc",$segment_array);
		 $desc = array_search("desc",$segment_array);
		
		 //get the records
		 if($this->uri->segment($do_orderby+1)=='admin'){
			 $sortby='id';
			}else{
				$sortby=$this->uri->segment($do_orderby+1);
			}
		 
		 $this->db->order_by($sortby, $this->uri->segment($do_orderby+2));
		
		 //getting the records and limit setting
		 if (ctype_digit($segment_array[$segment_count])) {
			
			$data['page']=$segment_array[$segment_count];
			$page=$segment_array[$segment_count];
			$this->db->limit($config['per_page'], $segment_array[$segment_count]);
			array_pop($segment_array);
		 }
		 else {
			$page=null;
			$data['page']=NULL;
			$this->db->limit($config['per_page']);
		 }
	
		 $config['base_url'] = site_url(join("/",$segment_array));
		 $config['uri_segment'] =count($segment_array)+1;
	
		  //initialize pagination
		 $this->pagination->initialize($config);
		 $data['results']=$this->adminmodel->getUserlist($uclientid=null,$type='users',$config["per_page"],$page);
		 $data["links"] = $this->pagination->create_links();
		
		 //load the view
		 $this->load->view('admin/users',$data);
		
		
	}
	
	
	
	/*List of All client*/
	function clients(){
		$this->load->library("pagination");
		$this->load->model('adminmodel');
		//page title
		 $data['title']='Client list';
		$data['menu']='4';
		 //pagination configurations

		 $data['total_row']= $this->adminmodel->getUserlist($uclientid=null,$type='client',null, null);
		 //die('dd');
		 $config['total_rows'] = count($data['total_row']);
		 $config['per_page'] = PER_PAGE_RECORD; /*DEFINE IN CONFIG/CONSTAANT.PHP*/;
		 $config['full_tag_open'] = '<div id="pagination">';
		 $config['full_tag_close'] = '</div>';
		
		 //get all the URI segments for pagination and sorting
		 $segment_array=$this->uri->segment_array();
		 $segment_count=$this->uri->total_segments();
		
		 //for ordering the data items
		 $do_orderby = array_search("orderby",$segment_array);
		
		 //asc and desc sorting
		 $asc = array_search("asc",$segment_array);
		 $desc = array_search("desc",$segment_array);
		
		 //get the records
		 if($this->uri->segment($do_orderby+1)=='admin'){
			 $sortby='id';
			}else{
				$sortby=$this->uri->segment($do_orderby+1);
			}
		 
		 $this->db->order_by($sortby, $this->uri->segment($do_orderby+2));
		
		 //getting the records and limit setting
		 if (ctype_digit($segment_array[$segment_count])) {
			
			$data['page']=$segment_array[$segment_count];
			$page=$segment_array[$segment_count];
			$this->db->limit($config['per_page'], $segment_array[$segment_count]);
			array_pop($segment_array);
		 }
		 else {
			$page=null;
			$data['page']=NULL;
			$this->db->limit($config['per_page']);
		 }
	
		 $config['base_url'] = site_url(join("/",$segment_array));
		 $config['uri_segment'] =count($segment_array)+1;
	
		  //initialize pagination
		 $this->pagination->initialize($config);
		 $data['results']=$this->adminmodel->getUserlist($uclientid=null,$type='client',$config["per_page"],$page);
		 $data["links"] = $this->pagination->create_links();
		
		 //load the view
		 $this->load->view('admin/clients',$data);
		
		
	}
	
	
	function addclient($id=null)
	{
		$data['menu']=4;
		$this->load->model('adminmodel');
		if($id){
			$data['title']='Edit Client';
			$data['clientDetail']=$this->adminmodel->getuserDetail($id,$roleid='2');
			
			if(@$data['clientDetail']['id']){
			$data['clientId']= $data['clientDetail']['id'];
			}else{$data['clientId']='';}
			/*Get more client_details tables*/
			$data['clientDetail']['moredetails'] = $this->adminmodel->getclientDetail($data['clientId']);
			//pr($data['clientDetail']);
			@$data['clientDetail']['companyName']=$data['clientDetail']['moredetails']['companyName'];
			@$data['clientDetail']['accountManager']=$data['clientDetail']['moredetails']['accountManager'];
			@$data['clientDetail']['clientAddress']=$data['clientDetail']['moredetails']['clientAddress'];
			@$data['clientDetail']['googleemail']=$data['clientDetail']['moredetails']['email'];
			
			/*Get Individual Client Contact person List*/
			$data['contact_person_detail']= $this->adminmodel->getcontact_person_detail($data['clientDetail']['moredetails']['id']);
			//pre($data['contact_person_detail']);
			
			/*Get Individual Clinet Service List*/
			$data['client_service_list_detail']= $this->adminmodel->getclient_service_detail($data['clientDetail']['moredetails']['id']);
			//pre($data['contact_person_detail']);
			
		}	
		else{
			$data['title']='Add Client';
		}
		/*Get All Defualt Folder list*/
			$data['folders'] = $this->adminmodel->getallfolders(null);

		/*Permission code here */
			$data['results'] = $this->adminmodel->getallpermissions(null);
			//pr($data['results']);

		/*Get only user permission List*/
			$data['userpermissions'] = $this->adminmodel->getuserpermissions($id);
			
			/*Decode Client selected file permissions*/
				if($data['userpermissions']){
					$userpermissionAry = json_decode($data['userpermissions']['permissionId']);
					foreach($userpermissionAry as $ky=>$val)
					{
						   $arraykey[$ky]=$userpermissionAry->$ky;	
					}
					$data['select_usr_permission']=$arraykey;
				}
		
		/*Get only Client Folder selected permission List*/
			$data['folderpermissions_array'] = $this->adminmodel->getclientfolderPermission($id);
			if($data['folderpermissions_array']){
				$folderpermissionAry = json_decode($data['folderpermissions_array']['folderpermissions']);
				foreach($folderpermissionAry as $ky=>$val)
				{
					//if($val=='yes'){
					   $folderarraykey[$ky]=$folderpermissionAry->$ky;	
					//}
				}
				
				$data['select_client_folder_permission']=$folderarraykey;
			}
			//pre($data['select_client_folder_permission']);

		if($this->session->userdata('loggedInAdmin')){
			if(!empty($data['clientDetail']['id'])){
			$data['clientId']= $data['clientDetail']['id'];
			}else{$data['clientId']='';}
			if ($this->form_validation->run()==false){
				
				$this->load->view('admin/manageclient',$data);
			}
		}
	}
	
	public function manageclient($id)
	{
		$this->load->model('adminmodel');
		$data['menu']='4';
		if($this->uri->segment(3) || $this->input->post('id')) /*Get existing client details*/
		{
			$id=$this->uri->segment(3);	
			$data['title']='Edit Client';
			//$this->load->view('admin/manageclient',$data);
		}
		else{ $data['title']='Add Client';
			$data['clientId']='';
			$id='';
		}
		
		if($this->input->post('btnsubmit'))
		{
			$id = $this->input->post('id');
			$this->form_validation->set_rules('userName', 'userName', 'required');
			if(!isset($id)){
				$this->form_validation->set_rules('googlepassword', 'google password', 'required|min_length[5]|max_length[55]');
			}
			//else { $this->form_validation->set_rules('googlepassword', 'google password', 'min_length[5]|max_length[55]');} 
			$this->form_validation->set_rules('companyName', 'Company Name', 'required|string');
			//$this->form_validation->set_rules('clientAddress', 'address', 'required');
			$this->form_validation->set_rules('userEmail', 'Email', 'required|email|valid_email');
			$this->form_validation->set_rules('userPhone', 'Phone', 'required|integer|min_length[10]|max_length[15]');
			$this->form_validation->set_rules('googleemail', 'google email', 'required|email|valid_email');
			
			if(!isset($id)){
				/*Contact person validation */
				$this->form_validation->set_rules('personname', 'Person Name', 'required|min_length[5]');
				$this->form_validation->set_rules('personprofession', 'Profession', 'required|min_length[3]');	
				$this->form_validation->set_rules('personemail', 'Email', 'required|valid_email|is_unique[client_contact_persons.email]');
				$this->form_validation->set_rules('personphone', 'Phone', 'required|integer|min_length[10]|max_length[15]');
				
				/*Client Service validation*/
				$this->form_validation->set_rules('serviceName', 'Service Name', 'required|min_length[3]');
				$this->form_validation->set_rules('serviceDescription', 'Description', 'required|min_length[3]');	
				$this->form_validation->set_rules('startingDate', 'Starting date', 'required');
				$this->form_validation->set_rules('endingDate', 'Ending date', 'required');
			}
			if ($this->form_validation->run()==false){
			$data['clientDetail']=$this->adminmodel->getuserDetail($id,$roleid='2');
			if(isset($data['clientDetail']['id'])){
				$data['clientId']= $data['clientDetail']['id'];
			}else{	$data['clientId']='';}
			
			/*Get All Defualt Folder list*/
			$data['folders'] = $this->adminmodel->getallfolders($userid=null);
		
			
			/*Permission code here */
			$data['results'] = $this->adminmodel->getallpermissions($userid=null);
			//pr($data['results']);
			/*Get only user permission List*/
			$data['userpermissions'] = $this->adminmodel->getuserpermissions($userid);
			//pr($data['userpermissions']);
			
			/*Get only Client Folder selected permission List*/
			$data['selectedpermissions'] = $this->adminmodel->getclientfolderPermission($userid);
			
			/*Decode Client selected file permissions*/
			if($data['userpermissions']){
				$userpermissionAry = json_decode($data['userpermissions']['permissionId']);
				foreach($userpermissionAry as $ky=>$val)
				{
					//if($val=='yes'){
					   $arraykey[$ky]=$userpermissionAry->$ky;	
					//}
				}
				//print_r($arraykey);
				$data['select_usr_permission']=$arraykey;
			}
		
			/*Decode Client selected folder permissions*/
			if($data['selectedpermissions']){
				$userpermissionAry = json_decode($data['selectedpermissions']['permissionId']);
				foreach($userpermissionAry as $ky=>$val)
				{
					//if($val=='yes'){
					   $arraykey[$ky]=$userpermissionAry->$ky;	
					//}
				}
				//print_r($arraykey);
				$data['select_client_folder_permission']=$arraykey;
			}
			
			/*Get more client_details tables*/
				$data['clientDetail']['moredetails'] = $this->adminmodel->getclientDetail($data['clientId']);
				@$data['clientDetail']['companyName']=$data['clientDetail']['moredetails']['companyName'];
				@$data['clientDetail']['accountManager']=$data['clientDetail']['moredetails']['accountManager'];
				@$data['clientDetail']['clientAddress']=$data['clientDetail']['moredetails']['clientAddress'];
				@$data['clientDetail']['googleemail']=$data['clientDetail']['moredetails']['email'];
			
				//@$data['contact_person_detail']['googleemail']=$data['contact_person_detail']['moredetails']['email'];
						
				$data['upload_error'] = "";
				$this->load->view('admin/manageclient',$data);
				//redirect("admin/addclient/$id");
				
			}else
			{
				$error = $this->adminmodel->saveUser($task='client');
				if($error){
					/*message*/
					if($error=='add'){$this->session->set_flashdata('message', '<div class="alert-success">Client add successfully.</div>');}
					elseif($error=='update'){
						$this->session->set_flashdata('message', '<div class="alert-success">Client Updated successfully </div>');
					}
					if($task=='client')
					{	redirect('admin/clients');	}
					else {	redirect('admin/clients');	}
				}else{
					$data['clientDetail']['userName'] = $this->input->post('username');
					$data['clientDetail']['userPassword'] = $this->input->post('password');
					$data['clientDetail']['userEmail'] = $this->input->post('email');
					$data['clientDetail']['companyName'] = $this->input->post('companyName');
					$data['clientDetail']['clientAddress'] = $this->input->post('clientAddress');
					$data['clientDetail']['userPhone'] = $this->input->post('userPhone');
					$data['clientDetail']['googleemail'] = $this->input->post('googleemail');
					$data['clientDetail']['googlepassword'] = $this->input->post('googlepassword');
					$data['clientDetail']['accountManager'] = $this->input->post('accountManager');
					$data['upload_error'] = $error['error'];
					$this->session->set_flashdata('message', '<div class="alert-error">Client not add, please try again!</div>');
					//$this->load->view('admin/manageclient',$data);
					redirect("admin/addclient/$id");
				}
				
				
			}
		}else {
				redirect("admin/addclient/$id");
			}	
		
	}
	
	
	
	
		/**
	* @ Function Name	: active
	* @ Function Params	: $id {array/integer}
	* @ Function Purpose 	: make Client status active
	* @ Function Returns	: 
	*/
	function active($id = '') {
		$this->load->model('adminmodel');		
		$result = false;
		//pr($id);
		if($this->uri->segment(3))
		{
			/*Get User detail*/
			$usrdetail = $this->adminmodel->getuserDetailbyId($id);
			if($usrdetail){
				$id = $usrdetail['userId'];	 /*User Only*/
				$usr="user";
			}else{ 
				$id = $this->uri->segment(3); /*Client only*/
				$usr="client";
			}
			$result = $this->adminmodel->status($id, 'active');
		}	    
		
		if ($result == true) {
		    echo $this->session->set_flashdata('message', "<div class='alert-success'>Active status set for $usr successfully.</div>");
		} else {
		    echo $this->session->set_flashdata('message', "<div class='alert-error'>No status set for $usr, please try again.</div>");
		}
		
		if($usr=='user'){
			redirect('admin/users');	
		}else{
			redirect('admin/clients');
		}
	}

	/**
	* @ Function Name	: inactive
	* @ Function Params	: $id {array/integer}
	* @ Function Purpose 	: make Client status inactive
	* @ Function Returns	: 
	*/
	function inactive($id = '') {
		$this->load->model('adminmodel');		
		$result = false;
		if($this->uri->segment(3))
		{
			/*Get User detail*/
			$usrdetail = $this->adminmodel->getuserDetailbyId($id);
			if($usrdetail){
				$id = $usrdetail['userId'];	 /*User Only*/
				$usr="user";
			}else{ 
				$id = $this->uri->segment(3); /*Client only*/
				$usr="client";
			}
			$result = $this->adminmodel->status($id, 'inactive');
		}
		if ($result == true) {
		    echo $this->session->set_flashdata('message', "<div class='alert-success'>Inactive status set for $usr successfully.</div>");
		} else {
		    echo $this->session->set_flashdata('message', "<div class='alert-error'>No status set for $usr, please try again.</div>");
		}
		if($usr=='user'){
			redirect('admin/users');	
		}else{
			redirect('admin/clients');
		}
	}
	
	
	/**
	* @ Function Name	: Delete
	* @ Function Params	: $id {array/integer}
	* @ Function Purpose 	: make Client status inactive
	* @ Function Returns	: 
	*/
	function delete($id = '') {
		$this->load->model('adminmodel');		
		$result = false;
		if($this->uri->segment(3))
		{
			/*Get User detail*/
			$usrdetail = $this->adminmodel->getuserDetailbyId($id);
			if($usrdetail){
				$id = $usrdetail['userId'];	 /*User Only*/
				$usr="User";
			}else{ 
				$id = $this->uri->segment(3); /*Client only*/
				$usr="Client";
			}
			$result = $this->adminmodel->deleteusers_clients($id);
		}
		if ($result == true) {
		    echo $this->session->set_flashdata('message', "<div class='alert-success'>$usr deleted successfully.</div>");
		} else {
		    echo $this->session->set_flashdata('message', "<div class='alert-error'>$usr not deleted, please try again.</div>");
		}
		if($usr=='User'){
			redirect('admin/users');	
		}else{
			redirect('admin/clients');
		}
	}
	
	
	/**
	* @ Function Name	: managecontactperoson
	* @ Function Params	: $id {array/integer}
	* @ Function Purpose 	: add new contact person for a client
	* @ Function Returns	: 
	*/	
	function managecontactperson($clientId=null, $id=null){
		$data['menu']='4';
		$data['clientId'] = $this->uri->segment(3);
		$this->load->model('adminmodel');
		if($id){
			$data['title']='Edit Contact person';
		}else{
			$data['title']='New Contact person';
		}
		if($this->input->post('btnsubmit'))
		{
			$this->form_validation->set_rules('name', 'Person Name', 'required|min_length[5]');
			$this->form_validation->set_rules('profession', 'Profession', 'required|min_length[3]');	
			$this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[client_contact_persons.email]');
			$this->form_validation->set_rules('phone', 'Phone', 'required|integer|min_length[10]|max_length[15]');
			if ($this->form_validation->run()==false){
				$this->load->view('admin/managecontactperson.php',$data);
			}else
			{
				$clientDetails = $this->adminmodel->getClientdetails($this->uri->segment(3));
				$client_detail_id=$clientDetails['id'];
				$cpersonname=array(
					'clientId'=>$client_detail_id,
					'name'=>$this->input->post('name'),
					'profession'=>$this->input->post('profession'),
					'email'=>$this->input->post('email'),
					'phone'=>$this->input->post('phone'),
					'createDate'=>date('Y-m-d H:i:s'),
				);
					/*edit contact person record*/
				if($this->input->post('contactpid'))
				{
					$cpid = $this->input->post('contactpid');
					$result = $this->adminmodel->savecontactperson($cpid,$this->uri->segment(3),$cpersonname);
				}else{
					/*addd new contact person record*/
					$result = $this->adminmodel->savecontactperson(null,$this->uri->segment(3),$cpersonname);
				}
				if($result)
				{	
					if(empty($cpid)){
						echo $this->session->set_flashdata('message', '<div class="alert-success">Contact persone added successfully.</div>');
					} else{
						echo $this->session->set_flashdata('message', '<div class="alert-success">Contact persone updated successfully.</div>');	
					}
				} else {
					echo $this->session->set_flashdata('message', '<div class="alert-error">Contact persone not added, please try again.</div>');
				}
				redirect('admin/clients');
				//continue
			}
			
		}else{
			if($id){
				$data['contact_person_detail']=$this->adminmodel->getcontact_person_detail($id);
			}
			$this->load->view('admin/managecontactperson.php',$data);
		}
		
	}
	
	
	
	/**
	* @ Function Name	: manageclientservice
	* @ Function Params	: $clientId of client / $id of service {array/integer}
	* @ Function Purpose 	: add new/ edit service contract for a client
	* @ Function Returns	: 
	*/
	function manageclientservice($clientId=null, $serviceid=null)
	{
		$data['clientId'] = $this->uri->segment(3);
		$data['menu']='4';
		$this->load->model('adminmodel');
		$this->load->library('utility');
		if($serviceid){
			$data['title']='Edit Service';
		}else{
			$data['title']='New Service';
		}
		if($this->input->post('btnsubmit'))
		{
			$this->form_validation->set_rules('serviceName', 'Service Name', 'required|min_length[3]');
			$this->form_validation->set_rules('serviceDescription', 'Description', 'required|min_length[3]');	
			$this->form_validation->set_rules('startingDate', 'Starting date', 'required');
			$this->form_validation->set_rules('endingDate', 'Ending date', 'required');
			if ($this->form_validation->run()==false){
				$this->load->view('admin/manageclientservice.php',$data);
			}else
			{
				$clientDetails = $this->adminmodel->getClientdetails($this->uri->segment(3));
				$client_detail_id=$clientDetails['id'];
				
				$sdate = $this->input->post('startingDate');
				$edate = $this->input->post('endingDate');				
				
				$stardate = $this->utility->dateFormat($sdate, 'Y-m-d H:i:s');
				$enddate = $this->utility->dateFormat($edate, 'Y-m-d H:i:s');
				
				//$stardate = date_format($sdate, 'Y-m-d H:i:s');
				//$enddate = date_format($edate, 'Y-m-d H:i:s');
				
				$clientservice=array(
					'clientId'=>$client_detail_id,
					'serviceName'=>$this->input->post('serviceName'),
					'serviceDescription'=>$this->input->post('serviceDescription'),
					'serviceUpload'=>$this->input->post('serviceUpload'),
					'startingDate'=>$stardate,
					'endingDate'=>$enddate,
				);
				//pr($clientservice);
					/*edit contact person record*/
				if($this->input->post('clientserviceid'))
				{
					$cpid = $this->input->post('clientserviceid');
					$result = $this->adminmodel->saveclientService($cpid,$this->uri->segment(3),$clientservice);
				}else{
					/*addd new contact person record*/
					$result = $this->adminmodel->saveclientService(null,$this->uri->segment(3),$clientservice);
				}
				if($result)
				{	
					if(empty($cpid)){
						echo $this->session->set_flashdata('message', '<div class="alert-success">Client service added successfully.</div>');
					} else{
						echo $this->session->set_flashdata('message', '<div class="alert-success">Client service updated successfully.</div>');	
					}
				} else {
					echo $this->session->set_flashdata('message', '<div class="alert-error">Client service not added, please try again.</div>');
				}
				redirect('admin/clientservices');
				//continue
			}
			
		}else{
			if($serviceid){
				
				$data['client_service_detail']=$this->adminmodel->getclient_service_detail($serviceid);
			}
			$this->load->view('admin/manageclientservice.php',$data);
		}	
		
	}
	/**
	* @ Function Name	: clientservices
	* @ Function Params	: $clientId
	* @ Function Purpose 	: Show all clients service and get individual client service
	* @ Function Returns	: 
	*/
	function clientservices($cId=null,$type=null){
		
		$this->load->library("pagination");
		$this->load->model('adminmodel');
		$this->load->helper('text');
		//page title
		$data['title']='Client Services';		
		$data['menu']='4';
			
			//pagination configurations
			if($cId && $type=="notall"){
				$data['total_row']= $this->adminmodel->getclientservicelist($cId,$type='client',null, null);
			}else{
			 $data['total_row']= $this->adminmodel->getclientservicelist($uclientid=null,$type='client',null, null);
			 //die('dd');
			}
			 $config['total_rows'] = count($data['total_row']);
			 $config['per_page'] = PER_PAGE_RECORD; /*DEFINE IN CONFIG/CONSTAANT.PHP*/;
			
			 //get all the URI segments for pagination and sorting
			 $segment_array=$this->uri->segment_array();
			 $segment_count=$this->uri->total_segments();
			
			 //for ordering the data items
			 $do_orderby = array_search("orderby",$segment_array);
			
			 //asc and desc sorting
			 $desc = array_search("desc",$segment_array);
			 $asc = array_search("asc",$segment_array);
			 
			
			 //get the records
			 if($this->uri->segment($do_orderby+1)=='admin'){
				 $sortby='cservice.id';
				}else{
					$sortby=$this->uri->segment($do_orderby+1);
				}
			 
			 $this->db->order_by($sortby, $this->uri->segment($do_orderby+2));
			
			 //getting the records and limit setting
			 if (ctype_digit($segment_array[$segment_count])) {
				
				$data['page']=$segment_array[$segment_count];
				$page=$segment_array[$segment_count];
				$this->db->limit($config['per_page'], $segment_array[$segment_count]);
				array_pop($segment_array);
			 }
			 else {
				$page=null;
				$data['page']=NULL;
				$this->db->limit($config['per_page']);
			 }
		
			 $config['base_url'] = site_url(join("/",$segment_array));
			 $config['uri_segment'] =count($segment_array)+1;
		
			  //initialize pagination
			 $this->pagination->initialize($config);
			 if($cId && $type=="notall"){
				$data['results']=$this->adminmodel->getclientservicelist($cId,$type='client',$config["per_page"],$page);
			}else{
			 $data['results']=$this->adminmodel->getclientservicelist($uclientid=null,$type='client',$config["per_page"],$page);
			}
			 $data["links"] = $this->pagination->create_links();
		
		 //load the view
		 $this->load->view('admin/clientservices.php',$data);
		
	}
	
	
	
	/**
	* @ Function Name	: cservicedelete
	* @ Function Params	: $id {array/integer}
	* @ Function Purpose 	: delete contact person from contact_person_tables.
	* @ Function Returns	: 
	*/
	function cservicedelete($clntid,$serviceid){
		$this->load->model('adminmodel');
		$data['title']='Contact person delete ';
		$result = $this->adminmodel->cservicedelete($clntid,$serviceid);
		if ($result == true)
		{
			echo $this->session->set_flashdata('message', '<div class="alert-success">Client service deleted successfully.</div>');
		} else {
			echo $this->session->set_flashdata('message', '<div class="alert-error">Client service not delete, please try again.</div>');
		}
		redirect("admin/clientservices");
	}
	
	
	/**
	* @ Function Name	: do_file_upload
	* @ Function Params	: $path / $filename
	* @ Function Purpose 	: upload file for contract service
	* @ Function Returns	: 
	*/
	function do_file_upload($path,$fileName){
		$config['upload_path'] = './uploads/'.$path;
		$config['allowed_types'] = 'gif|jpg|png|jpeg|pdf|doc|docx';		
		$this->load->library('upload', $config);
		$this->upload->do_upload($fileName);
		return array('error'=>$this->upload->display_errors(),'upload_data' => $this->upload->data());
	}
	
	
	
	/**
	* @ Function Name	: managecontactperoson
	* @ Function Params	: $id {array/integer}
	* @ Function Purpose 	: add new contact person for a client
	* @ Function Returns	: 
	*/
	
	function contactperson($userId=null)
	{
		$this->load->library("pagination");
		$this->load->model('adminmodel');
		$data['title']='List of contact person';
		$data['menu']='4';
		
		/*Get client id from client_detail table*/
		$clientDetails = $this->adminmodel->getClientdetails($userId);
		$clientId=$clientDetails['id'];			
		//$data['contacpersonList'] = $this->adminmodel->getContactpersonlist($clientId);
		//$this->load->view('admin/contactpersonlist.php',$data);
		
		
		
		
		$data['total_row']=$this->adminmodel->getContactpersonlist($clientId,$type=null,null, null);
		 
		 $config['total_rows'] = count($data['total_row']);
		 $config['per_page'] = PER_PAGE_RECORD; /*DEFINE IN CONFIG/CONSTAANT.PHP*/
		
		 //get all the URI segments for pagination and sorting
		 $segment_array=$this->uri->segment_array();
		 /*bcz of incriment for client id*/
		 array_push($segment_array,'');
		 
		 $segment_count=$this->uri->total_segments();
		 /*incriment for client id*/
		 //$last_segment = end($this->uri->segment_array());
 		 $segment_count=$segment_count+1;	
		
		 //for ordering the data items
		 $do_orderby = array_search("orderby",$segment_array);
		
		 //asc and desc sorting
		 $asc = array_search("asc",$segment_array);
		 $desc = array_search("desc",$segment_array);
		
		 //get the records
		 if($this->uri->segment($do_orderby+1)=='admin'){
			 $sortby='id';
			}else{
				$sortby=$this->uri->segment($do_orderby+1);
			}
		 
		 $this->db->order_by($sortby, $this->uri->segment($do_orderby+2));
		
		 //getting the records and limit setting
		 if (ctype_digit($segment_array[$segment_count])) {
			$data['page']=$segment_array[$segment_count];
			$page=$segment_array[$segment_count];
			$this->db->limit($config['per_page'], $segment_array[$segment_count]);
			array_pop($segment_array);
			//array_pop($segment_array);
		 }
		 else {
			$page=null;
			$data['page']=NULL;
			$this->db->limit($config['per_page']);
		 }
	
		 $config['base_url'] = site_url(join("/",$segment_array));
		 $config['uri_segment'] =count($segment_array)+1;
	
		  //initialize pagination
		 $this->pagination->initialize($config);
		 
		 //$data['contacpersonList'] = $this->adminmodel->getContactpersonlist($clientId);
		 //$this->adminmodel->getContactpersonlist($clientId,$type=null,null, null);
		 //echo $config["per_page"];
		 //echo $page;
		 $data['contacpersonList']=$this->adminmodel->getContactpersonlist($clientId,$type=null,$config["per_page"],$page);
		 $data["links"] = $this->pagination->create_links();
		 
		//pr($data["links"]);
		 //load the view
		 $this->load->view('admin/contactpersonlist.php',$data);
		
	}
	/**
	* @ Function Name	: contactpersondelete
	* @ Function Params	: $id {array/integer}
	* @ Function Purpose 	: delete contact person from contact_person_tables.
	* @ Function Returns	: 
	*/
	function contactpersondelete($userid,$cpid){
		$this->load->model('adminmodel');
		$data['title']='Contact person delete ';
		$result = $this->adminmodel->contactpersondelete($userid,$cpid);
		if ($result == true)
		{
			echo $this->session->set_flashdata('message', '<div class="alert-success">Contact persone deleted successfully.</div>');
		} else {
			echo $this->session->set_flashdata('message', '<div class="alert-error">Contact persone not delete, please try again.</div>');
		}
		redirect("admin/contactperson/$userid");
	}
	/**
	* @ Function Name	: setpermission
	* @ Function Params	: $id {array/integer}
	* @ Function Purpose 	: Show all permissions
	* @ Function Returns	: 
	*/
	function setpermission($userid)
	{
		$data['menu']='5';
		$this->load->model('adminmodel');
		$data['title'] = 'Set permisssion';
		
		/*Get user records, This function define on common_helper*/
		$rows = get_user($userid);
		if($rows){$data['username']=$rows->userName;}else{$data['username']=null;}
		
		//pr($rows);
		/*Get all permission list*/
		$data['results'] = $this->adminmodel->getallpermissions($userid);
		
		/*Get only user permission List*/
		$data['userpermissions'] = $this->adminmodel->getuserpermissions($userid);
		//pr($data['userpermissions']);
		if($data['userpermissions']){
			$userpermissionAry = json_decode($data['userpermissions']['permissionId']);
			foreach($userpermissionAry as $ky=>$val)
			{
				//if($val=='yes'){
				   $arraykey[$ky]=$userpermissionAry->$ky;	
				//}
			}
			//print_r($arraykey);
			$data['select_usr_permission']=$arraykey;
		}
		if($userid){
			$data['userid']	= $userid;
		}else {  $data['userid']= null;	}
		//pr($data['result']);
		if($this->input->post('setpermission') && $this->input->post('userId'))
		{
				//json_encode($sequential)
				//json_decode($sequential)
				$permissionnamevalue = json_encode($this->input->post('pid'));
				$permissionarray=array(
					'permissionId'=>$permissionnamevalue,
					'userId'=>$this->input->post('userId'),
					'userPerDate'=>date('Y-m-d H:i:s'),
				);
				//pr($clientservice);
					/*edit contact person record*/
				if($this->input->post('permissionid'))
				{
					$perid = $this->input->post('permissionid');
					$result = $this->adminmodel->savepermissions($perid,$userid,$permissionarray);
				}else{
					/*addd new contact person record*/
					$result = $this->adminmodel->savepermissions($perid=null,$userid,$permissionarray);
				}
				if($result)
				{	
					if(empty($userid)){
						echo $this->session->set_flashdata('message', '<div class="alert-success">Permissions set successfully.</div>');
					} else{
						echo $this->session->set_flashdata('message', '<div class="alert-success">Permissions updated successfully.</div>');	
					}
				} else {
					echo $this->session->set_flashdata('message', '<div class="alert-error">Permission not set, please try again.</div>');
				}
				redirect("admin/setpermission/$userid");
				//continue
		}else{
			$this->load->view('admin/setpermission.php',$data);
		}
	}
	
	/**
	* @ Function Name		: _sendWelcomeMail
	* @ Function Params	: 
	* @ Function Purpose 	: sends mail to all user from admin side.
	* @ Function Returns	: 
	*/
	private function _sendWelcomeMail($type) {
	//pr($_SESSION);	
        $from = $this->session->userdata('admin_email');;
        $userName = $this->input->post("userEmail");
        $email = $this->input->post("userEmail");
        $first_name = $this->input->post("fname");
        $last_name = $this->input->post("lname");
        $password = $this->input->post("userPassword");
        $subject = "Congratulation! Your Account has been successfully created.";
        $message = '';
        $message .= '<table width="100%" border="0" cellspacing="0" cellpadding="0">';
        $message .= '<tr>';
        $message .= '<td height="26" style="font-family:Tahoma, Arial, sans-serif; font-size:11px;color:#575757;"><strong>Dear ' . ucfirst($first_name) . ucfirst($last_name) . '</strong></td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td style="font-family:Tahoma, Arial, sans-serif; font-size:11px; color:#575757; line-height:15px; padding-bottom:10px;">Your registration was successful. You will find your registration data below. Please keep this information secure & safe.</td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td height="5"></td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td align="left">';
        $message .= '<table width="287" border="0" bgcolor="#F18231" cellspacing="1" cellpadding="6" style="border:solid 3px #F18231;">';
        $message .= '<tr>';
        $message .= '<td colspan="2"><strong style="color:#FFF;">Login Information</strong></td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td bgcolor="#ffffff" width="100"><strong>Username:</strong></td>';
        $message .= '<td width="270" bgcolor="#ffffff">' . @$userName . '</td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td  bgcolor="#ffffff"><strong>Password</strong></td>';
        $message .= '<td  bgcolor="#ffffff">' . @$password . '</td>';
        $message .= '</tr>';
        $message .= '</table>';
        $message .= '</td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td height="25">&nbsp;</td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td height="25"></td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td>Thanks and Regards,<br />';
        $message .= '</td>';
        $message .= '</tr>';
        $message .= '</table>';
        $body = getNotificationTheme('Congratulation! Your Account has been successfully created.', '<font style="font-size:16px;">Welcome to <a href="' . base_url() . '" style="color:#fff">' . $this->config->item('siteName') . '</a>!</font>', $message);
        $this->email->from($from);
        $this->email->to($email);
        $this->email->subject('Congratulation! Your Account has been successfully created');
        $this->email->message($body);
        $this->email->set_mailtype('html');
	$this->email->send();
        return TRUE;
    }
	
	/**
	* @ Function Name		: _sendAdminPassword
	* @ Function Params	: 
	* @ Function Purpose 	: sends mail to admin on forgot password
	* @ Function Returns	: 
	*/
	private function _sendAdminPassword($adminArray = array()) {
        $from = $this->config->item('adminEmail');
        $to = $adminArray->admEmail;
        $name = $adminArray->admUsername;
        $password = $adminArray->admPassword;
        $siteURL = $this->config->item('siteURL');

        $subject = $siteURL . " Password Recovery.";

        $message = '';
        $message .='<tr>
                        <td bgcolor="#F18231" style="font-family:segoe UI, Arial, sans-serif; font-size:13px; color:#FFF; padding:6px 10px;">
                           <font style="font-size:15px;">' . $subject . '</font>
                        </td>
                    </tr>';
        $message .= '<tr>';
        $message .= '<td valign="top" bgcolor="#ffffff" style="padding:12px;">
                              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td height="26" style="font-family:Tahoma, Arial, sans-serif; font-size:11px;color:#575757;">
                                        <strong>Hi Administrator,</strong>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="font-family:Tahoma, Arial, sans-serif; font-size:11px; color:#575757; line-height:15px; padding-bottom:10px;">
                                    You will find your login data below. Please keep this information secure & safe.
                                    </td>
                                </tr>';
        $message .='<tr>
                                <td height="5">
                                </td>
                            </tr>
                            <tr>
                                <td align="left">
                                    <table width="287" border="0" bgcolor="#F18231" cellspacing="1" cellpadding="6" style="border:solid 3px #F18231;">
                                        <tr>
                                            <td colspan="2">
                                                <strong style="color:#FFF;">Login Information</strong>
                                            </td>
                                        </tr>
                                        <tr>';
        $message .= '<td bgcolor="#ffffff" width="100"><strong>Username</strong></td>';
        $message .= '<td width="270" bgcolor="#ffffff">' . @$name . '</td>';
        $message .= '</tr>';
        $message .= '<tr>';
        $message .= '<td  bgcolor="#ffffff"><strong>Password</strong></td>';
        $message .= '<td  bgcolor="#ffffff">' . @$password . '</td>';
        $message .= '</tr>';
        $message .='</table>';
        $message .='</td>
                                </tr>
                                <tr>
                                    <td height="25">&nbsp;</td>
                                </tr>
                                <tr>';
        $message .='<td>
                            </td>
                        </tr>
                        <tr>
                            <td height="25"></td>
                        </tr>
                        <tr style="color:black;">

                        ';
        $message .= '<td>Regards,<br />';
        $message .= 'Customer Support Team<br />';
		$message .= '<a href="' . base_url() . '">' . $this->config->item('siteName') . '</a><br />';
        $message .= '</td></tr>';
        $message .= '</table>';
        $message .= '</tr>';
        $body = getNotificationTheme($siteURL . ' Password Recovery.', $message, '');
        $this->email->from($from);
        $this->email->to($to);
        $this->email->subject($siteURL . ' Password Recovery.');
        $this->email->message($body);
        $this->email->set_mailtype('html');
        if ($this->email->send()) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */