<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends MY_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -  
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in 
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	var $menu;
	
	public function index()
	{
		//$this->load->library('googleplus');
		//$this->googleplus->people->get('me'); // when authorized
		//$this->googleplus->people->get('115414977082318263605'); // that's me :-)
		//echo base_url(); 		
		$this->load->model('usermodel');
		$this->load->helper('cookie');
		if($this->session->userdata('loggedIn'))
		redirect('/home/index.php');
		$this->menu=1;
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->form_validation -> set_error_delimiters('<span class="error">', '</span>');
		$this->form_validation->set_rules('username', 'Username', 'required|callback_username_check');
		$this->form_validation->set_rules('password', 'Password', 'required|callback_password_check');	
				
		if ($this->form_validation->run()==false){
			$this->load->view('user/login');
		}else{
			//die($this->form_validation->run());
			$this->session->set_userdata('loggedIn',true);
			redirect('/home/index.php','refresh');
		}
	}
	function username_check($str){
		if ($str != 'pradeep') {
			$this->form_validation->set_message('username_check', 'The %s field you have entered is not correct');
			return FALSE;
		}else {
			return TRUE;
		}
	}
	function password_check($str){
		if ($str != 'pradeep') {
			$this->form_validation->set_message('password_check', 'The %s field you have entered is not correct');
			return FALSE;
		}else{
			return TRUE;
		}
	}
	
	/*function register()
	{
		if(isset($_POST) && @$_POST['submitLogin']==='Submit')
		{
			redirect('user/submitUser');	
		}
		else{			
			$this->load->view('user/register',$data);
		}
	}
	function editUser()
	{
		if($this->session->userdata('loggedIn')){
			$this->load->helper('form');
			$this->load->library('form_validation');
			$id = $this->uri->segment(3,'0');
			$data['product'] = $this->adminmodel->getProduct($id);
			$this->load->view('admin/add-edit-product',$data);
		}else{
			redirect('/user');
		}
	}
	
	function submitUser(){
		$this->load->model('usermodel');	
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');	
		$this->form_validation->set_rules('cpassword', 'Confirm password', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		
		if ($this->form_validation->run()==false){

			$data['users']['userName'] = $this->input->post('username');
			$data['users']['userPassword'] = $this->input->post('password');
			$data['users']['userEmail'] = $this->input->post('email');
			$data['users']['userGender'] = $this->input->post('gender');
			$data['users']['userImage'] = $this->input->post('image');
			$data['users']['userState'] = $this->input->post('state');
			$data['upload_error'] = "";
			$this->load->view('user/register',$data);
			
		}else
		{
			$error = $this->adminmodel->saveUser();
			die($error);
			if($error==2){
				redirect('user/');
			}else{
				$data['users']['userName'] = $this->input->post('username');
				$data['users']['userPassword'] = $this->input->post('password');
				$data['users']['userEmail'] = $this->input->post('email');
				$data['users']['userGender'] = $this->input->post('gender');
				$data['users']['userImage'] = $this->input->post('image');
				$data['users']['userState'] = $this->input->post('state');
				$data['upload_error'] = $error['error'];
				$this->load->view('admin/add-edit-product',$data);
			}
			
			
		}
		//$this->load->view('user/register');
		
	}*/
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */