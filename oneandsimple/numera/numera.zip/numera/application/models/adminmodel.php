<?php
class Adminmodel extends CI_Model {
    
        var $title   = '';
        var $content = '';
        var $date    = '';
    
	function __construct()
        {
            // Call the Model constructor
            parent::__construct();
        }

	function getLoginResult($username, $password) {
		$result = $this->db->get_where('users', array('userName' => $username,'userPassword'=>$password,'userRoleId'=>'1'));
		return $result->row_array();
		
	}

        /*Check user name is exist or not */
	function checkUserexist($usr){
		$result = $this->db->get_where('users', array('userName' => $usr,'userRoleId'=>'1'));
		return $result->row_array();
	}
	
	/*Check user password is exist or not */
	function checkusrpwdxist($pwd){
		$result = $this->db->get_where('users', array('userPassword' => $pwd,'userRoleId'=>'1'));
		return $result->row_array();
	}
	
	/*Count total number of user rows and get all user according the roles*/
	function totolNumberofuser($roleid,$task=null){
		$this->db->select('id,userEmail');
		$result = $this->db->get_where('users',array('userRoleId'=>$roleid));
		if($task=='client'){			
			return $result->result_array();
		}else{
			return $result->num_rows();
		}
		
		//echo $this->db->last_query();die;
	}
	/*Check admin email is exist or not*/
	function checkusremail($str){
		$result = $this->db->get_where('users', array('userEmail' => $str,'userRoleId'=>'1'));
		return $result->row_array();	
	}
	
	/*update upassword*/
	
	function updatepassword($userId=null,$newpwd=null){
		$save = array(
			'userPassword'=>$newpwd,
		);
		$result=$this->db->update('users',$save,array('id'=>$userId));
		//echo $this->db->last_query();
		//die('welcome');
		return $result;
	}
	/*Get user detail by Id from users table*/
	function getuserDetail($uid=null,$roleid=null){		
		$result = $this->db->get_where('users', array('id' => $uid,'userRoleId'=>"$roleid"));
		return $result->row_array();	
	}
	
	/*Get User detail by Id from users_detail table*/
	function getuserDetailbyId($id=null){		
		$result = $this->db->get_where('user_details', array('id' => $id));
		return $result->row_array();	
	}
	
	/*Get user complete detail by Id from users table*/
	function getuserFullDetail($uid=null,$roleid=null){		
		$this->db->select('udetail.id,udetail.userId as userId,usr.userName,usr.userEmail,usr.userImage,usr.userPhone,usr.userRoleId,
				  usr.userStatus,udetail.fname,udetail.lname,udetail.profession,udetail.clientId as clientId,
				  usrclnt.userName as clientname');    
		$this->db->from('users AS usr');
		$this->db->where("usr.id = $uid");
		$this->db->where("usr.userRoleId =".$roleid);
		$this->db->join('user_details AS udetail', 'udetail.userId = usr.id', 'INNER');
		$this->db->join('users AS usrclnt', 'usrclnt.id = udetail.clientId', 'INNER');
		$this->db->join('users_permission AS upermission', 'upermission.userId = usr.id','left');
		$result = $this->db->get();
		//echo $this->db->last_query();die;
		return $result->row_array();
	}

	/*Get Client detail by Id from client_details table*/
	function getclientDetail($uid=null){
		if($uid){
			$this->db->select('cdetail.*, gglClientDtl.email,gglClientDtl.password');
			$this->db->from('client_details AS cdetail');
			$this->db->join('google_login_detail AS gglClientDtl', 'gglClientDtl.userId = cdetail.userId ','LEFT');
			$this->db->where("cdetail.userId = $uid");
			$result = $this->db->get();
			//$result = $this->db->get_where('client_details', array('userId' => $uid));
			return $result->row_array();
		}
	}
	
	
	function saveUser($task=null)
	{
		
		$save = array();
		if($this->session->userdata('loggedInAdmin') && $task=='admin')
		{ $id = $this->session->userdata('id');}
		else{	$id = $this->input->post('id'); }
		
		if(@$_FILES['userImage']['name']!=''){
			$uploaded_data = $this->do_file_upload('users/','userImage');
		}else{
			if($this->input->post('userImage_old'))
			{
				$uploaded_data['upload_data']['file_name']=$this->input->post('userImage_old');	
			}else{
				$uploaded_data = array('error'=>'','upload_data'=>array('file_name'=> 'no-image.gif'));
			}
		}
		
		if($uploaded_data['error']==''){
			
			$saveclient = array(					
					'userName'=>$this->input->post('userName'),
					'userEmail'=>$this->input->post('userEmail'),
					'userPhone'=>$this->input->post('userPhone'),
					'userImage'=>$uploaded_data['upload_data']['file_name'],
					'userUpdateDate'=>date('Y-m-d H:i:s')
					);
						
			$saveuser = array(					
					'userEmail'=>$this->input->post('userEmail'),
					'userPhone'=>$this->input->post('userPhone'),
					'userImage'=>$uploaded_data['upload_data']['file_name'],
					'userUpdateDate'=>date('Y-m-d H:i:s')
					);
			$saveadmin = array(					
					'userName'=>$this->input->post('userName'),
					'userEmail'=>$this->input->post('userEmail'),
					'userPhone'=>$this->input->post('userPhone'),
					'adminFooterTxt'=>$this->input->post('adminFooterTxt'),					
					'userUpdateDate'=>date('Y-m-d H:i:s')
					);
			
			
		if($id){ /*Update tables*/
				//pr($_POST);
				if(isset($_FILES['userImage']['name']) && !empty($_FILES['userImage']['name'])){
					$result = $this->db->get_where('users', array('id'=>$id));
					$imageDetail = $result->row_array();
					if($imageDetail['userImage']!=='no-image.gif' && $task!='admin'){
						unlink('./uploads/users/'.$imageDetail['userImage']);
					}
				}
				if($task=='client')
				{
					$saveclient = array(					
					'userName'=>$this->input->post('userName'),
					'userEmail'=>$this->input->post('userEmail'),
					'userPhone'=>$this->input->post('userPhone'),
					'userImage'=>$uploaded_data['upload_data']['file_name'],
					'userUpdateDate'=>date('Y-m-d H:i:s')
					);
					$this->db->update(TBL_USERS,$saveclient,array('id'=>$id));
				}elseif($task=='user'){
					$fname= $this->input->post('fname');
					$lname= $this->input->post('lname');
					$fullname= $fname.' '.$lname;
					$userId = $this->input->post('userId');
					$this->db->update(TBL_USERS,$saveuser,array('id'=>$userId ));
					//die($this->db->last_query());
				}				
				else{ 	/*For admin only */
					$this->db->update(TBL_USERS,$saveadmin,array('id'=>$id));
				}
				
				/*Save data in client details*/
				/*update client information*/
				if($task=='client')/*For Client Detail table*/
				{
					$save_client=array(
							'userId'=>$id ,
							'companyName'=>$this->input->post('companyName'),
							'clientAddress'=>$this->input->post('clientAddress'),
							'accountManager'=>$this->input->post('accountManager'),
						);
					//pr($save_client);
					if($id){ $this->db->update('client_details',$save_client,array('userId'=>$id));}
					else{	$this->db->insert('client_details',$save_client);  }
					
					/*Save Client Google id and password into google_login_detail table`*/
					if($this->input->post('googlepassword')){
						$save_client_googlelogin=array(
							'userId'=>$id ,
							'email'=>$this->input->post('googleemail'),
							'password'=>$this->input->post('googlepassword'),
						);
					}else{
						$save_client_googlelogin=array(
							'userId'=>$id ,
							'email'=>$this->input->post('googleemail'),
						);	
					}
					if($id){$this->db->update('google_login_detail`',$save_client_googlelogin,array('userId'=>$id));}
					else{	$this->db->insert('google_login_detail`',$save_client_googlelogin);  }
					
					/*Get client id from from  */
					$result = $this->db->get_where('client_details', array('userId'=>$id));
					$clientarray = $result->row_array();
					$client_id=$clientarray['id'];
					
					/*Update table client_contact_person*/
					$clientcontactpersonlist = $this->input->post('cp');
					if (is_array($clientcontactpersonlist) && count($clientcontactpersonlist) > 0)
					{
						foreach($clientcontactpersonlist as $val)
						{							
							$save_client_contactperson_array=array(
							'name'=>$val['personname'],
							'profession'=>$val['personprofession'],
							'email'=>$val['personemail'],
							'phone'=>$val['personphone'],
							);
							if(isset($val['id'])){
								$this->db->update('client_contact_persons',$save_client_contactperson_array,array('id'=>$val['id']));
							}else{
								$save_client_contactperson_array=array_merge($save_client_contactperson_array,array('clientId'=>$client_id));
								$this->db->insert('client_contact_persons',$save_client_contactperson_array);	
							}
						}
					}
					/*Update table client service*/
					$clientservicearraylist = $this->input->post('services');
						if (is_array($clientservicearraylist) && count($clientservicearraylist) > 0)
						{
							foreach($clientservicearraylist as $val)
							{							
								$save_client_service_array=array(
								'serviceName'=>$val['serviceName'],
								'serviceDescription'=>$val['serviceName'],
								'startingDate'=>$val['startingDate'],
								'endingDate'=>$val['endingDate'],
								);
								if(isset($val['id'])){
									$this->db->update('client_contract_services',$save_client_service_array,array('id'=>$val['id']));
								}else{
									$save_client_service_array=array_merge($save_client_service_array,array('clientId'=>$client_id));
									$this->db->insert('client_contract_services',$save_client_service_array);
								}
								
							}
						}
					//die($this->db->last_query());
				}
				
				/*if user id is exist then update else add new user of client*/
				if($task=='user'){
					$save_user=array(
							'fname'=>$this->input->post('fname'),
							'lname'=>$this->input->post('lname'),
							'profession'=>$this->input->post('profession'),
							'clientId'=>$this->input->post('clientid'),
						);
					if($id){
						$this->db->update('user_details',$save_user,array('userId'=>$id));
						}
					else{$this->db->insert('user_details',$save_user);  }
				}
				
				/*update user users_permission table */
					$permissionnamevalue = json_encode($this->input->post('pid'));
					$permissionarray=array(
						'permissionId'=>$permissionnamevalue,
						'userPerDate'=>date('Y-m-d H:i:s'),
					);
					if($id){
					$this->db->update('users_permission',$permissionarray,array('userId'=>$id));
					}
					else{$this->db->insert('users_permission',$permissionarray); }
					//die($this->db->last_query());
				/*update user users_folder_permission */
					$folderpersmission = json_encode($this->input->post('folderpermission'));
					$folderpermissionarray=array(
					'folderpermissions'=>$folderpersmission,
					'userPerDate'=>date('Y-m-d H:i:s'),
					);
					if($id){
					$this->db->update('users_folder_permission',$folderpermissionarray,array('userId'=>$id));
					}
					else{$this->db->insert('users_folder_permission',$folderpermissionarray); }
					
				return 'update';
			
			}
			else{ /*Inter into tables*/
				if($task=='client')
				{
					/*$save = array(
					'userName'=>$this->input->post('userName'),
					'userPassword'=>md5($this->input->post('userPassword')),
					'userEmail'=>$this->input->post('userEmail'),
					'userPhone'=>$this->input->post('userPhone'),
					'userImage'=>$uploaded_data['upload_data']['file_name'],
					'userRoleId'=>'2',	
					'userUpdateDate'=>date('Y-m-d H:i:s'),
					'userCreateDate'=>date('Y-m-d H:i:s'),
					);*/
					$save = array(
					'userPassword'=>md5($this->input->post('userPassword')),
					'userRoleId'=>'2',	
					'userUpdateDate'=>date('Y-m-d H:i:s'),
					'userCreateDate'=>date('Y-m-d H:i:s'),
					);
					//pr($saveclient);
					$saveclient=array_merge($saveclient,$save);
					/*'userImage'=>$uploaded_data['upload_data']['file_name'],*/
					$this->db->insert(TBL_USERS,$saveclient);
					$insertId = $this->db->insert_id();
					
				}elseif($task=='user'){ /*Add user information for client*/
					$fname= $this->input->post('fname');
					$lname= $this->input->post('lname');
					$fullname= $fname.' '.$lname;
					$save = array(
					'userName'=>$fullname,
					'userPassword'=>md5($this->input->post('userPassword')),
					'userRoleId'=>'3',	
					'userCreateDate'=>date('Y-m-d H:i:s')
					);
					$saveuser=array_merge($saveuser,$save);
					$this->db->insert(TBL_USERS,$saveuser);
					$insertId = $this->db->insert_id();
				}
				else{
					/*Add Admin information*/
					$saveadmin = array(
					'userName'=>$this->input->post('userName'),
					'userEmail'=>$this->input->post('userEmail'),
					'userPhone'=>$this->input->post('userPhone'),
					'userUpdateDate'=>date('Y-m-d H:i:s'),
					'userCreateDate'=>date('Y-m-d H:i:s')
					);
					$this->db->insert(TBL_USERS,$saveadmin);
					$insertId = $this->db->insert_id();	
				}	
				
				
				/*Add default folder list for all user and client in folder_master table*/
					/*for($i=0; $i<=3;$i++)	//Create default 4 folder for each users and clients
					{
						$save_bothuser_folder=array(
							'userId'=>$insertId ,
							'folderName'=>$this->input->post('companyName'),
						);
						$this->db->insert('folder_master',$save_bothuser_folder);
					}*/
				
				/*save client information*/
				if($task=='client'){
					$save_client=array(
							'userId'=>$insertId ,
							'companyName'=>$this->input->post('companyName'),
							'clientAddress'=>$this->input->post('clientAddress'),
							'accountManager'=>$this->input->post('accountManager'),
						);
					if($id){$this->db->update('client_details',$save_client,array('userId'=>$id)); }
					   else{$this->db->insert('client_details',$save_client);
						$insertclientId = $this->db->insert_id();
					   }
				
					/*Save Client Google id and password into google_login_detail table`*/
					$save_client_googlelogin=array(
							'userId'=>$insertId ,
							'email'=>$this->input->post('googleemail'),
							'password'=>$this->input->post('googlepassword'),
						);
					if($id){
						$this->db->update('google_login_detail`',$save_client_googlelogin,array('userId'=>$id));
						}
					else{	$this->db->insert('google_login_detail`',$save_client_googlelogin);  }
					
					/* Add record client_contact_persons*/
					$save_client_contactperson=array(
							'clientId'=>$insertclientId ,
							'name'=>$this->input->post('personname'),
							'profession'=>$this->input->post('personprofession'),
							'email'=>$this->input->post('personemail'),
							'phone'=>$this->input->post('personphone'),
							'createDate'=>date('Y-m-d H:i:s'),
						);
					/*Insert record*/
					$this->db->insert('client_contact_persons',$save_client_contactperson);
					
					/*Inser More record in contact person*/
					
					$clientcontactpersonlist = $this->input->post('cp');
					if (is_array($clientcontactpersonlist) && count($clientcontactpersonlist) > 0)
					{
						foreach($clientcontactpersonlist as $val)
						{							
							$save_client_contactperson_array=array(
							'clientId'=>$insertclientId ,
							'name'=>$val['personname'],
							'profession'=>$val['personprofession'],
							'email'=>$val['personemail'],
							'phone'=>$val['personphone'],
							'createDate'=>date('Y-m-d H:i:s'),
							);
							$this->db->insert('client_contact_persons',$save_client_contactperson_array);
						}
					}
					
					
					/* Add record in client_contract_services table*/
						$sdate = $this->input->post('startingDate');
						$edate = $this->input->post('endingDate');				
						
						$save_client_services=array(
							'clientId'=>$insertclientId ,
							'serviceName'=>$this->input->post('serviceName'),
							'serviceDescription'=>$this->input->post('serviceDescription'),
							'serviceUpload'=>$this->input->post('serviceUpload'),
							'startingDate'=>$sdate,
							'endingDate'=>$edate,
						);
					/*Insert record*/
					$this->db->insert('client_contract_services',$save_client_services);
					
					/*Add more client service*/
						$clientservicearraylist = $this->input->post('services');
						if (is_array($clientservicearraylist) && count($clientservicearraylist) > 0)
						{
							foreach($clientservicearraylist as $val)
							{							
								$save_client_service_array=array(
								'clientId'=>$insertclientId ,
								'serviceName'=>$val['serviceName'],
								'serviceDescription'=>$val['serviceName'],
								'startingDate'=>$val['startingDate'],
								'endingDate'=>$val['endingDate'],
								);
								$this->db->insert('client_contract_services',$save_client_service_array);
							}
						}
				}
				
				if($task=='user'){
					$save_user=array(
							'userId'=>$insertId ,
							'fname'=>$this->input->post('fname'),
							'lname'=>$this->input->post('lname'),
							'profession'=>$this->input->post('profession'),
							'clientId'=>$this->input->post('clientid'),
							
						);
					if($id){$this->db->update('user_details',$save_user,array('userId'=>$id)); }
					  
					else{$this->db->insert('user_details',$save_user);  }
				}
				
				/*Add Client Permission*/
						$permissionnamevalue = json_encode($this->input->post('pid'));
						$permissionarray=array(
							'permissionId'=>$permissionnamevalue,
							'userId'=>$insertId,
							'userPerDate'=>date('Y-m-d H:i:s'),
						);
					/*Insert record */
					$this->db->insert('users_permission',$permissionarray);
					
					
					
					
					/*Add Client Folder Permission*/
						$folderpersmission = json_encode($this->input->post('folderpermission'));
						$folderpermissionarray=array(
							'folderpermissions'=>$folderpersmission,
							'userId'=>$insertId,
							'userPerDate'=>date('Y-m-d H:i:s'),
						);
					/*Insert record */
					$this->db->insert('users_folder_permission',$folderpermissionarray);
				return 'add';
			}
			
			
		}else{
			return $uploaded_data;
		}
	}
	function do_file_upload($path,$fileName){
		$config['upload_path'] = './uploads/'.$path;
		$config['allowed_types'] = 'gif|jpg|png|jpeg';		
		$this->load->library('upload', $config);
		$this->upload->do_upload($fileName);
		return array('error'=>$this->upload->display_errors(),'upload_data' => $this->upload->data());
	}	
	
	
	/*Get all Type of User and Client*/
	function getUserlist($uclientid=null,$type=null,$limit=null, $start=null){
			
		if($type=='client'){			
			if($uclientid){				
				$this->db->where('userClientId', $uclientid);
			}else{
				$this->db->where('userRoleId', '2');
				
				/*filter record*/
				if($this->input->post('clientsearch'))
				{
					$serchby=$this->input->post('searchby');
					$searchvalue=$this->input->post('searchvalue');
					$this->db->where($serchby, "$searchvalue");
				}
			}
			if($limit && $start){
				$this->db->limit($limit, $start);		
			}else{
				$this->db->order_by("id", "desc");
			}
			
			$result = $this->db->get(TBL_USERS);				
			//die($this->db->last_query());
			return $result->result_array();
		}
		
		if($type=='users'){			
			if($uclientid){				
				$this->db->where('userClientId', $uclientid);
			}else{
				/*filter record*/
				if($this->input->post('clientsearch'))
				{
					$serchby=$this->input->post('searchby');
					$searchvalue=$this->input->post('searchvalue');
					/*Get client Id by user name*/
					if($serchby==='udetails.clientId'){
						$this->db->select('userName,id');    
						$result2 = $this->db->get_where('users', array('userName' => $searchvalue,'userRoleId'=>'2'));
						$client_Detail = $result2->row_array();
						$searchvalue = $client_Detail['id'];
						//pr($client_Detail);
					}
					$this->db->where($serchby, "$searchvalue");
				}
			}
			if($limit && $start){
				$this->db->limit($limit, $start);		
			}
				//$this->db->where('userRoleId', '3');				
				//$this->db->where('cservice.clientId', "$uclientid");
				$this->db->select('udetails.*,usr.userImage, usr.userName as usrlgn_name,usr.userEmail,usr.userStatus,usr.userCreateDate,clntusr.userName as clientName,clntusr.userEmail as clientemail');    
				$this->db->from('user_details as udetails ');
				$this->db->join('users as usr', 'usr.id=udetails.userId and usr.userRoleId=3', 'INNER');
				$this->db->join('users as clntusr', 'clntusr.id=udetails.clientId and usr.userRoleId=3', 'INNER');
				$result = $this->db->get();
			
			//$result = $this->db->get(TBL_USERS);				
			//die($this->db->last_query());
			return $result->result_array();
		}
		
	}
	
	/**
	* @ Function Name	: deleteusers_clients
	* @ Function Params	: $id {Array}
	* @ Function Purpose 	: delete users and client  by id also if users then delete from user_detail , user_permission and users tables,
	* 			  if client then delete from client_contact_person, contract_serivce, client_detail, user_persmission.googl_login_detail and users tables.	
	* @ Function Returns	: 
	*/
	function deleteusers_clients($id) {
		//pr($id);
		$this->db->select("userRoleId,userImage");
		$this->db->where("id IN (" . $id . ")", "", FALSE);
		$result = $this->db->get("users");
		$rowarray = $result->row_array();
		if($rowarray)
		{
			
			if($rowarray['userImage']!=='no-image.gif'){
				unlink('./uploads/users/'.$rowarray['userImage']);
			}
			if($rowarray['userRoleId']==3) /*For all Users*/
			{
				$this->db->where("userId IN (" . $id . ")", "", FALSE); /*delete user_details table*/		
				$this->db->delete('user_details');
								
				$this->db->where("userId IN (" . $id . ")", "", FALSE);	/*delete user permission table*/		
				$this->db->delete('users_permission');
				
				$this->db->where("userId IN (" . $id . ")", "", FALSE);	/*delete users_folder_permission table*/		
				$this->db->delete('users_folder_permission');
				
				
				$this->db->where("id IN (" . $id . ")", "", FALSE);	/*delete user permission table*/		
				$this->db->delete('users');
				return true;
			}
			if($rowarray['userRoleId']==2) /*For All Clients*/
			{
				$this->db->select("id");
				$this->db->where("userId IN (" . $id . ")", "", FALSE);
				$result = $this->db->get("client_details");
				$clientarray = $result->row_array();
				if($clientarray);
				{
					$clntid=$clientarray['id'];
					$this->db->where("clientId IN (" . $clntid . ")", "", FALSE);	/*delete client_contract_services table*/		
					$this->db->delete('client_contract_services');
					
					$this->db->where("clientId IN (" . $clntid . ")", "", FALSE);	/*delete client_contact_persons table*/		
					$this->db->delete('client_contact_persons');
				}
				
				$this->db->where("userId IN (" . $id . ")", "", FALSE);	/*delete google_login_detail table*/		
				$this->db->delete('google_login_detail');
				
				$this->db->where("userId IN (" . $id . ")", "", FALSE);	/*delete folder_master table*/		
				$this->db->delete('folder_master');
				
				$this->db->where("userId IN (" . $id . ")", "", FALSE);	/*delete users_permission table*/		
				$this->db->delete('users_permission');
				
				
				$this->db->where("userId IN (" . $id . ")", "", FALSE); /*delete user_details table*/		
				$this->db->delete('client_details');
								
				
				$this->db->where("id IN (" . $id . ")", "", FALSE);	/*delete user permission table*/		
				$this->db->delete('users');
				return true;
			}
			
		}
	}

	/**
	* @ Function Name	: status
	* @ Function Params	: $id {Array/integer}, $status {active/inactive}
	* @ Function Purpose 	: delete users by id
	* @ Function Returns	: 
	*/
	function status($id, $status) {		
		$data = array('userStatus' => $status,);
		$this->db->where("id IN ('" . $id . "')", '', false);
		//$this->db->update('users', $data);
		return $this->db->update('users', $data);
		//echo $this->db->last_query();
		//die;
	}
	
	/**
	* @ Function Name	: savecontactperson
	* @ Function Params	: $id {Array/integer}
	* @ Function Purpose 	: delete users by id
	* @ Function Returns	: 
	*/
	function savecontactperson($cpid=null, $userid=null,$array=null) {
		if($cpid){
			return $this->db->update('client_contact_persons',$array,array('id'=>$cpid));
		}else{
			return $this->db->insert('client_contact_persons',$array);
		}
	}
	/**
	* @ Function Name	: getClientdetails
	* @ Function Params	: $id {Array/integer}
	* @ Function Purpose 	: get Client details for client_details tables
	* @ Function Returns	: 
	*/
	function getClientdetails($userId)
	{
		
		$result = $this->db->get_where('client_details',array('userId'=>$userId));
		//echo $this->db->last_query();die;
		return $result->row_array();
	}
	
	/**
	* @ Function Name	: getContactpersonlist
	* @ Function Params	: clientId {Array/integer}
	* @ Function Purpose 	: get Contact person list for client_contact_persons table
	* @ Function Returns	: 
	*/
	/*Get all Type of User and Client*/
	function getContactpersonlist($uclientid=null,$type=null,$limit=null, $start=null){

		/*filter record*/
		if($this->input->post('clientsearch'))
		{
			$serchby=$this->input->post('searchby');
			$searchvalue=$this->input->post('searchvalue');
			
			$this->db->where($serchby, "$searchvalue");
		}
		if($limit && $start){
			$this->db->limit($limit, $start);		
		}
			$this->db->where('clientId', "$uclientid");
			$result = $this->db->get('client_contact_persons');				
			return $result->result_array();
			//echo $result->result_array();
			//echo $this->db->last_query();
	}
	
	/**
	* @ Function Name	: getcontact_person_detail
	* @ Function Params	: contactpersonId {Array/integer}
	* @ Function Purpose 	: get Contact person list for client_contact_persons table
	* @ Function Returns	: 
	*/
	function getcontact_person_detail($cpid)
	{
		$result = $this->db->get_where('client_contact_persons',array('clientId'=>$cpid));
		return $result->result_array();
	}
	
	/**
	* @ Function Name	: contactpersondelete
	* @ Function Params	: $userid,$cpid  {Array/integer}
	* @ Function Purpose 	: Delete contact person information
	* @ Function Returns	: 
	*/
	
	function contactpersondelete($userid=null,$cpid=null) {
		if($userid && $cpid){
			$this->db->where("id IN (" . $cpid . ")", "", FALSE);
			return $this->db->delete('client_contact_persons');
			
		}
	}
	
	/**
	* @ Function Name	: savecontactperson
	* @ Function Params	: $id {Array/integer}
	* @ Function Purpose 	: delete users by id
	* @ Function Returns	: 
	*/
	function saveclientService($csid=null, $userid=null,$array=null) {
		
		/*if($_FILES['userImage']['name']!=''){
			$uploaded_data = $this->do_file_upload('users/','userImage');
		}*/		
		if($csid){
			return $this->db->update('client_contract_services',$array,array('id'=>$csid));
		}else{
			return $this->db->insert('client_contract_services',$array);
		}
	}
	
	/**
	* @ Function Name	: getclientservicelist
	* @ Function Params	: $uclientid, $type, $limit, $start  {Array/integer}
	* @ Function Purpose 	: Get all clients service and indivisual client service
	* @ Function Returns	: 
	*/
	function getclientservicelist($uclientid=null,$type='client',$limit=null, $start=null){
		/*filter record*/
		if($this->input->post('clientsearch'))
		{
			$serchby=$this->input->post('searchby');
			$searchvalue=$this->input->post('searchvalue');
			
			$this->db->where($serchby, "$searchvalue");
		}
		if($limit && $start){
			$this->db->limit($limit, $start);		
		}
		if($uclientid)
		{
			$this->db->where('cservice.clientId', "$uclientid");
			$this->db->select('cservice.*,user.userName,user.id as usrid');    
			$this->db->from('client_contract_services AS cservice');
			$this->db->join('client_details AS cdetail', 'cservice.clientId = cdetail.id', 'INNER');
			$this->db->join('users AS user', 'cdetail.userId = user.id', 'INNER');
			$result = $this->db->get();
			//return $result->result_array();
			//$result = $this->db->get('client_contract_services');				
			//echo $this->db->last_query();die;
			//die('if');
			return $result->result_array();
			
		}else{
			$this->db->select('cservice.*,user.userName,user.id as usrid');    
			$this->db->from('client_contract_services AS cservice');
			$this->db->join('client_details AS cdetail', 'cservice.clientId = cdetail.id', 'INNER');
			$this->db->join('users AS user', 'cdetail.userId = user.id', 'INNER');
			//$this->db->group_by('cservice.clientId');
			$result = $this->db->get();
			return $result->result_array();
		}
		
	}
	
	/**
	* @ Function Name	: getclient_service_detail
	* @ Function Params	: contactpersonId {Array/integer}
	* @ Function Purpose 	: get Contact person list for client_contact_persons table
	* @ Function Returns	: 
	*/
	function getclient_service_detail($clientId)
	{
		$result = $this->db->get_where('client_contract_services',array('clientId'=>$clientId));
		return $result->result_array();
	}
	
	/**
	* @ Function Name	: contactpersondelete
	* @ Function Params	: $clntid,$serviceid  {Array/integer}
	* @ Function Purpose 	: Delete of client service.
	* @ Function Returns	: 
	*/
	
	function cservicedelete($clntid=null,$serviceid=null){
		if($clntid && $serviceid){
			$this->db->where('clientId', "$clntid");
			$this->db->where("id IN (" . $serviceid . ")", "", FALSE);
			return $this->db->delete('client_contract_services');
		}
	}
	
	/**
	* @ Function Name	: getallpermissions
	* @ Function Params	: $userId {Array/integer}
	* @ Function Purpose 	: get all permission list.
	* @ Function Returns	: 
	*/
	function getallpermissions($usrId=null){
		$result = $this->db->get('users_permission_master');
		//die($this->db->last_query());
		return $result->result_array();
	}
	
	/**
	* @ Function Name	: getallfolders
	* @ Function Params	: $userId {Array/integer}
	* @ Function Purpose 	: get all Default folder list.
	* @ Function Returns	: 
	*/
	function getallfolders($usrId=null){
		$result = $this->db->get('folder_master');
		return $result->result_array();
	}
	
	
	
	
	
	/**
	* @ Function Name	: getallpermissions
	* @ Function Params	: $userId {Array/integer}
	* @ Function Purpose 	: get all permission list.
	* @ Function Returns	: 
	*/
	function getuserpermissions($userId=null){
		$result = $this->db->get_where('users_permission',array('userId'=>"$userId"));
		//die($this->db->last_query());
		return $result->row_array();
	}
	
	/*Get client folder permissions*/
	
	function getclientfolderPermission($userId=null){
		$result = $this->db->get_where('users_folder_permission',array('userId'=>"$userId"));
		return $result->row_array();
	}
	
	/**
	* @ Function Name	: savepermissions
	* @ Function Params	: $userId {Array/integer}
	* @ Function Purpose 	: get all permission list.
	* @ Function Returns	: 
	*/
	function savepermissions($perid,$userId,$permissionarray){
		if($perid){
			return $this->db->update('users_permission',$permissionarray,array('userId'=>$userId,'id'=>$perid));
		}else{
			return $this->db->insert('users_permission',$permissionarray);
		}
	}
	
}		
?>
