<?php
class Usermodel extends CI_Model {
    
        var $title   = '';
        var $content = '';
        var $date    = '';
    
        function __construct()
        {
            // Call the Model constructor
            parent::__construct();
        }
        
       function saveUser()
	{
		$save = array();
		$id = $this->input->post('id');			
		if($_FILES['image']['name']!=''){
			$uploaded_data = $this->do_file_upload('users/','image');
		}else{
			$uploaded_data = array('error'=>'','upload_data'=>array('file_name'=> 'no-image.gif'));
		}
              	if($uploaded_data['error']==''){
			if($id){
				$save = array(
                                'userName'      => $this->input->post('username'),
				'userPassword'  => $this->input->post('password'),
				'userEmail'     => $this->input->post('email'),
				'userGender'    => $this->input->post('gender'),
				'userState'     => $this->input->post('state'),
	       			'userImage'     => $uploaded_data['upload_data']['file_name'],
				'userUpdateDate'=> date('Y-m-d H:i:s')
				);
				$this->db->update(TBL_PRODUCTS,$save,array('id'=>$id));
			}else{
				$save = array(
				'title'=>$this->input->post('title'),
				'body'=>$this->input->post('body'),
				'image'=>$uploaded_data['upload_data']['file_name'],
				'updated'=>date('Y-m-d H:i:s'),
				'created'=>date('Y-m-d H:i:s')
				);
				$this->db->insert(TBL_PRODUCTS,$save);
			}
			return 2;
			
		}else{
			return $uploaded_data;
		}
	}
	function do_file_upload($path,$fileName){
		$config['upload_path'] = './uploads/'.$path;
		$config['allowed_types'] = 'gif|jpg|png|jpeg';
		$this->load->library('upload', $config);
		$this->upload->do_upload($fileName);
		return array('error'=>$this->upload->display_errors(),'upload_data' => $this->upload->data());
	}
    
    }

?>