<?php $this->load->view('admin_header')?>
<div class="login-page">
	<div class="login-logo"><a href="#"><img src="<?php echo base_url()?>images/logo.png" alt="" /></a></div>
	<div class="login-form">
		<div class="login-top"><?php echo $title; ?></div>
		<div class="login-center">
			<div><?php echo $this->session->flashdata('message'); ?> </div>
			<?php $attributes = array('name' => 'login', 'id' => 'login');?>
			<?php echo form_open('admin',$attributes);?>
				<div>
					<div class="input-div">
						<span><img src="<?php echo base_url()?>images/user.png" alt="Username" /></span>
						<input placeholder="Username" type="text" name="username" id="username" class="required" style="text-align:left"/>
					</div>
					<?php echo form_error('username'); ?>
				</div>
				<div>	
					<div id="input-div" class="input-div"> <span><img src="<?php echo base_url()?>images/pass.png" alt="Password"  /></span>
						<input placeholder="Password" type="password" class="required" name="password" style="text-align:left"/>
					</div>
					<?php echo form_error('password'); ?>
				</div>
				<div>
					<div class="input-radio">
						<input class="radio-input" name="chk_remember_me" type="radio" <?php echo ((($this->input->cookie('admin_name') != "") && ($this->input->cookie('admin_pass') != "")) ? "checked='yes'" : "No"); ?> />
						<small>Remember Me</small>
						<input value="Sign-in" class="sign" type="submit" />
					</div>
				</div>
			<?php echo form_close();?>		
		</div>
	</div>
	<div class="forgot-pass">
	  <p>Forgot your password ? no worries, <a href="<?php echo base_url()?>/admin/forgotepassword">click here </a>to reset your password.</p>
	  <p class="foo-border">2013 &#169; Numera, Powered by one and simple</p>
	</div>
</div>
<?php $this->load->view('admin_footer')?>
