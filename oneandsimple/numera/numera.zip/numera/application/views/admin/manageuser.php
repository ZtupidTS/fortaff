<?php $this->load->view('admin_header')?>
     <div class="headind">
	     <h2><?php echo $title; ?></h2>
		<?php if($this->uri->segment(3) && $userId){?>
			<span class="admin-right-menu">
				<!--<a href="<?php echo site_url();?>admin/setpermission/<?php echo $this->uri->segment(3);?>">Set permissions </a><a>|</a>-->
				<a href="<?php echo site_url();?>admin/adduser/<?php echo $this->uri->segment(3);?>">Add User </a>
				<!--<a>|</a><a href="<?php echo site_url();?>admin/manageclientservice/<?php echo $this->uri->segment(3);?>">Add Service </a><a>|</a>-->
				<!--<a href="<?php echo site_url();?>admin/managecontactperson/<?php echo $this->uri->segment(3);?>">Add contact person</a>-->
			</span>
		<?php } ?>	
     </div>
	
     <div class="tab-menu">
	  <div class="tab-content"></br>
	       <?php echo $this->session->flashdata('message'); ?>
		<br/>
	       <?php //pr($userDetail); ?>
	       <?php $attributes = array('name' => 'manageuser', 'id' => 'manageuser');?>
	       <?php echo form_open_multipart("admin/manageuser/$userId/",$attributes);?>
	       <div class="main-tab">
			 <div class="tab-content-left">
			      
				   <ul class="tab-field">
					<li>
						 <span><?php echo form_label('Client Name :', 'clientid','class="required"');?><em>*</em></span>
						 <div class="input-divs">
						       <select name="clientid" id="clientid" class="select required" >
							    <option value = "">- Select -</option>
							    <?php if(isset($clientlist)){
								 foreach($clientlist as $val)
								 {?>
								      <option value = "<?php echo $val['id']; ?>" <?php if($val['id']==@$userDetail['clientId']){ echo "selected";} ?>><?php echo $val['userEmail'];?></option>
								 
							    <?php } }?>
						       </select>
						 </div>
						 <?php echo form_error('userName'); ?>
					</li>
					<li>
						 <span><?php echo form_label('User Login Email:','userEmail','class="required"')?><em>*</em></span>
						 <div class="input-divs">
						 <?php echo form_input('userEmail',@$userDetail['userEmail'],'id="userEmail"');?>
						 </div>
						 <?php echo form_error('userEmail');?>
					</li>
					 
					 <!--<li>
						 <span><?php //echo form_label('User Login Name:', 'userName','class="required"');?></span>
						 <div class="input-divs">
						 <?php //echo form_input('userName', @$userDetail['userName'],'id="userName"');?>
						 </div>
						 <?php //echo form_error('userName'); ?>
					</li>-->
					 <?php  if(empty($userDetail['id'])) {?>
					<li>
						 <span><?php echo form_label('Password:', 'userPassword','class="required"');?><em>*</em></span>
						 <div class="input-divs">
						 <?php echo form_password('userPassword', @$userDetail['userPassword'],'id="userPassword"');?>
						 </div>
						 <?php echo form_error('userPassword'); ?>
					</li>
					 <?php } ?>
					
					<li>
						 <span><?php echo form_label('First Name:', 'fname','class="required"');?><em>*</em></span>
						 <div class="input-divs">
						 <?php echo form_input('fname', @$userDetail['fname'],'id="fname"');?>
						 </div>
						 <?php echo form_error('fname'); ?>
					</li>
					<li>
						 <span><?php echo form_label('Last Name:', 'lname','class="required"');?><em>*</em></span>
						 <div class="input-divs">
						 <?php echo form_input('lname', @$userDetail['lname'],'id="lname"');?>
						 </div>
						 <?php echo form_error('lname'); ?>
					</li>
				       
					<li>
						 <span><?php echo form_label('Profession:', 'profession','class="required"');?><em>*</em></span>
						 <div class="input-divs">
						 <?php echo form_input('profession', @$userDetail['profession'],'id="profession"');?>
						 </div>
						 <?php echo form_error('profession'); ?>
					</li>
				       
					<li><span><?php echo form_label('Phone:', 'userPhone','class="required"');?><em>*</em></span>
						 <div class="input-divs">
						 <?php echo form_input('userPhone', @$userDetail['userPhone'],'id="userPhone" maxlength="15"');?>
						 </div>
						 <?php echo form_error('userPhone'); ?>
					</li>
					<li>
					 <span><?php echo form_label('Image:','userImage','class="required"')?></span>
						 <div class="input-divs">
						 <?php echo form_upload('userImage','id="image"')?>
						 </div>
						 <?php echo form_error('userImage');?>
						 <?php if(isset($userDetail['userImage'])){ ?>
						 <img src="<?php echo base_url()?>/uploads/users/<?php echo @$userDetail['userImage'];?>" style="width:80px;float: right;margin-top: 5px;margin-right: 13px;"/>
						 <?php } ?>
						 <?php echo form_hidden('userImage_old', @$userDetail['userImage'],'id="userimage"');?>
					 </li>
				   </ul>
			 </div>
			 <div class="tab-content-left2">
			 <!--Tab 3 Set client permissions-->
			      <ul class="tab-field">
			      <li><i><strong>Set Permission</strong></i></li>
			      <li>
				   <div class="stdListing">
				   <?php  
				   if(@$userpermissions['permissionId']){
				   $permissionarray=json_decode($userpermissions['permissionId']);
				   }
				   ?>
					<table width="100%" cellspacing="0" cellpadding="0" border="0">
					     <colgroup>
					     <col width="25">
					     <col width="250">
					     </colgroup>
					     <tbody>
						  <tr>
						       <th scope="col">Permissions</th>
						       <th scope="col">Status</th>
						  </tr>
						  <?php if(count($results )>0)
						  { 	$i=0;?>
						       <?php foreach($results as $permissionlist)
						       {
							    if ($i % 2 == 1) {  $class = "alternateRow";}
							    else {	$class = "";	}
							    ?>
							    <tr class="<?php echo $class;?>">
								 <td scope="col"><?php echo ucwords($permissionlist['permissionName']); ?></td>
								 <td scope="col"><?php //echo $permissionlist['id'] ?>
								      <div>
									   <?php $id = $permissionlist['id']; $chk =  '0'; $i = 1;
									   if(isset($select_usr_permission))
									   {
										foreach($select_usr_permission as $k=>$val)
										{
										     if($i==$permissionlist['id'])
										     {
											  if($val=='yes')
											  {
											  ?>
											  <div style="float:left"> 
											       <div class="radio-input">Yes</div>
											       <input class="radio-input" name="pid[<?php echo $permissionlist['id'];?>]" type="radio" value="yes" id="<?php echo $permissionlist['id'];?>" <?php echo "checked='checked'";?>/>
											  </div>
											  <div style="float:left">
											       <div class="radio-input">No</div>
											       <input class="radio-input" name="pid[<?php echo $permissionlist['id'];?>]" type="radio" value="no" id="<?php echo $permissionlist['id'];?>" <?php //if($ky==$permissionlist['id'] && $val=='no'){ echo "checked='unchecked'";}?>/>
											  </div>
											  <?php
											  }else
											  { ?>
											       <div style="float:left"> 
												    <div class="radio-input">Yes</div>
												    <input class="radio-input" name="pid[<?php echo $permissionlist['id'];?>]" type="radio" value="yes" id="<?php echo $permissionlist['id'];?>" />
											       </div>
											       <div style="float:left">
												    <div class="radio-input">No</div>
												    <input class="radio-input" name="pid[<?php echo $permissionlist['id'];?>]" type="radio" value="no" id="<?php echo $permissionlist['id'];?>" <?php echo "checked='checked'";?><?php //if($ky==$permissionlist['id'] && $val=='no'){ echo "checked='unchecked'";}?>/>
											       </div>
										<?php     }
										     }
										     $i++;
										}
									   } if(empty($select_usr_permission)){ ?>
										<div style="float:left"> 
										     <div class="radio-input">Yes</div>
										     <input class="radio-input" name="pid[<?php echo $permissionlist['id'];?>]" type="radio" value="yes" id="<?php echo $permissionlist['id'];?>" />
										</div>
										<div style="float:left">
										     <div class="radio-input">No</div>
										     <input class="radio-input" name="pid[<?php echo $permissionlist['id'];?>]" type="radio" value="no" id="<?php echo $permissionlist['id'];?>" <?php echo "checked='checked'";?><?php //if($ky==$permissionlist['id'] && $val=='no'){ echo "checked='unchecked'";}?>/>
										</div>
										
									   <?php } ?>
								      </div>
								 </td>
							    </tr>
						  <?php } ?>
					     <?php }
					else{	?>
					     <tr>
						  <td scope="col" colspan="7"><div class="alert-error">No result found to be display here.</div></td>
					     </tr>
					<?php } ?>
					<tr>  <td scope="col" colspan="7"> &nbsp;</td></tr>
					     <tr>
						  <td scope="col" colspan="7"> <strong>Folders</strong></td>
					</tr>
					<tr>
					     <th scope="col"></th>
					     <th scope="col"></th>
					</tr>
					
					<!--Folder Listing-->
					<?php //pre($folders); ?>
					<?php if(count($folders )>0) { $i=0;?>
					<?php foreach($folders as $folderslist) {
					if ($i % 2 == 1) {  $class = "alternateRow";}
					else {	$class = "";	}
					?>
					<tr class="<?php echo $class;?>">
					     <td scope="col"><?php echo ucwords($folderslist['folderName']); ?></td>
					     <td scope="col"><?php //echo $permissionlist['id'] ?>
					     <div>
						  <?php
						  $id = $folderslist['id'];
						  $chk =  '0';
						  $i = 1;
						  if(isset($select_client_folder_permission)){
						       foreach($select_client_folder_permission as $k=>$val){
							    if($k==$folderslist['id']){
							    ?>
							    <div class="clear"></div>
							    <div style="float:left">
							    <?php if(@$val->Createfolder=='accept'){?>
							    <div class="radio-input">Add folder <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Createfolder]" value="accept" checked="checked"></div>
							    <?php }else{?>
							    <div class="radio-input">Add folder <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Createfolder]" value="accept" ></div>	
							    <?php }														
							    if(@$val->Createfile=='accept'){?>
							    <div class="radio-input">Add file <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Createfile]" value="accept" checked="checked"></div>
							    <?php }else{ ?>
							    <div class="radio-input">Add file <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Createfile]" value="accept"></div>
							    <?php } if(@$val->Rename=='accept'){?>
							    <div class="radio-input">Rename <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Rename]" value="accept" checked="checked"></div>
							    <?php }else{?>
							    <div class="radio-input">Rename <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Rename]" value="accept"></div>
							    <?php }if(@$val->Delete=='accept'){?>	
							    <div class="radio-input">Delete <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Delete]" value="accept" checked="checked"></div>
							    <?php }else{?>
							    <div class="radio-input">Delete <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Delete]" value="accept" ></div>
							    <?php }?>
							    </div>
							    <?php 	 
							    }
							    $i++;
							    }
						       } if(empty($select_client_folder_permission))
						       { ?>
							    <div class="clear"></div>
							    <div style="float:left">
								 <div class="radio-input">Add folder <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Createfolder]" value="accept" checked="checked" ></div>
								 <div class="radio-input">Add file <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Createfile]" value="accept" checked="checked"></div>
								 <div class="radio-input">Rename <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Rename]" value="accept" checked="checked"></div>
								 <div class="radio-input">Delete <input type="checkbox" name="folderpermission[<?php echo $folderslist['id']?>][Delete]" value="accept" checked="checked"></div>
							    </div>	
						  <?php } ?>
					     </div>
					</td>
					</tr>
					<?php } ?>
					<?php } else {?>
					<tr>
					     <td scope="col" colspan="7"><div class="alert-error">No result found to be display here.</div></td>
					</tr>
					<?php } ?>
					</tbody>
					</table>
				   </div>
			      </li>
			 </ul>			
		    </div>
	       </div>
	       <div class="input-radio" style="float:left">
		    <?php echo form_hidden('id', @$userDetail['userId'],'id="user_detail_id" maxlength="15"');?>
		    <?php echo form_hidden('userId', @$userDetail['userId'],'id="userid" maxlength="15"');?>
		    <input value="Submit" class="sign" type="submit" name="btnsubmit">
	       </div>
	       <?php echo form_close();?>		
		 
		</div>
	</div>
<?php $this->load->view('admin_footer')?>