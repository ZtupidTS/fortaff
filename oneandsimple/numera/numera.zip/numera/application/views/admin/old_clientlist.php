<?php $this->load->view('header')?>
<div id="bodytopmainPan">
	<div id="bodytopPan">
	<h2>Client List</h2>
	<p>
		<div id="user_changepassword">
			<div><?php echo $this->session->flashdata('message'); ?> </div>
			<?php 
				if($this->uri->segment(5)){
				
					if($this->uri->segment(5)=='desc'){
						$orderby='asc';
					}else{ $orderby='desc';}
				}else{ $orderby='desc';}
			?>
			<table cellspacing=5 width="100%">
				<tr>
					<th colspan="5">
						<form method="post" id="searchform">Search Client by
						
							<select name="searchby">
								<option value="userName">Name</option>
								<option value="userEmail">Email</option>
								<option value="userGender">Gender</option>
								<option value="userStatus">Status</option>
							</select>
							<?php echo form_input('searchvalue', set_value('search'),'id="searchvalue"');?>
							<?php echo form_error('searchvalue'); ?>
							<input type="submit" value="Search" name="clientsearch"/>
						</form>
					</th>
					<th></th>
					<th></th>
					<th><a href="<?php echo site_url();?>admin/addclient">Add Client</a></th>
				</tr>
				<tr>
					<th colspan="5"></th>
					<th></th>
					<th></th>
					<th></th>
				</tr>
				<tr>
					<th>Select</th>
					<th>Image</th>
					<th><a href="<?php echo site_url();?>admin/manageclient/orderby/userName/<?php echo $orderby; ?>">Client Name</a></th>
					<th><a href="<?php echo site_url();?>admin/manageclient/orderby/userEmail/<?php echo $orderby; ?>">Email</a></th>
					<th><a href="<?php echo site_url();?>admin/manageclient/orderby/userGender/<?php echo $orderby; ?>">Gender</a></th>
					<th><a href="<?php echo site_url();?>admin/manageclient/orderby/userStatus/<?php echo $orderby; ?>">Status</a></th>
					<th><a href="<?php echo site_url();?>admin/manageclient/orderby/userCreateDate/<?php echo $orderby; ?>">Register Date</a></th>
					<th>Actions</th>
				</tr>
				<?php if(count($results )>0) {?>
					<?php foreach($results as $clist) { ?>
					<tr>
						<td><input type="checkbox" value="<?php echo $clist['id'] ?>" id="<?php echo $clist['id'] ?>"></td>
						<td><img src="<?php echo site_url().'uploads/users/'.$clist['userImage'];?>" style="width:40px;hieght:40px" name="<?php echo $clist['id'] ?>" title="<?php echo $clist['userName'] ?>"></td>
						<td><?php echo $clist['userName']; ?></td>
						<td><?php echo $clist['userEmail']; ?></td>
						<td><?php echo $clist['userGender']; ?></td>
						<td><?php echo $clist['userStatus']; ?></td>
						<td><?php echo $clist['userCreateDate']; ?></td>
						<td>	<select name="action">
								<option>Select</option>
								<option value="Edit">Edit</option>
								<option value="delete">Delete</option>
								<option value="users">Users</option>
							</select>
						</td>
					</tr>
					<?php  } ?>
				<?php } else {?>
				<tr>
					<td colspan="7"><div class="alert-error">No result found to be display here.</div></td>
					
				</tr>
				<?php } ?>
			</table>
			<?php echo $links; ?>
		</div>
		<?php //echo anchor('user/register','Register'); ?>
	</p>	    
	</div>
</div>
<?php $this->load->view('footer')?>
