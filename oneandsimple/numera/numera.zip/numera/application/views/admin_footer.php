    <?php if($this->session->userdata('loggedInAdmin')) {?>
                    </div><!--<div class="section">-->
                </div> <!--<div class="main-contnt">--> 
                <div class="clear"></div>
            </div>
            <div class="footer">
                <?php $footertxt = get_adminFooter();
                    if(isset($footertxt->adminFooterTxt) && !empty($footertxt->adminFooterTxt)){
                ?>
                    <p><?php echo date('Y');  echo $footertxt->adminFooterTxt ?></p>
                <?php } else {?>
                    <p><?php  echo date('Y');?> � umera, Powered by one and simple</p>    
                <?php } ?>
                <a href="#"><img src="<?php echo base_url();?>images/oneandsimple-logo.png" alt="" /></a>
            </div>
            <div class="clear"></div>
        </div>
    <?php } ?>        
  <!--<div id="footermainPan">
    <div id="footerPan">
	  <p class="html"><?php echo anchor('admin','Admin');?></p>
		  <ul>
		  <li><a href="#">Home</a>|</li>
		  <li><a href="#">About</a> </li>
		  <?php if($this->session->userdata('loggedInAdmin')) {?>
		  <li>|<a href="<?php echo site_url()?>admin/changepassword">Change password</a>|</li>
		  <li><a href="<?php echo site_url()?>admin/editprofile">Edit My profile</a>|</li>
		  <li><a href="<?php echo site_url()?>admin/manageclient">Manage Client</a>|</li>
		  <li><a href="<?php echo site_url()?>admin/logout">Logout</a></li>
		  <?php } ?>
	   </ul>
	  <p class="copyright">�OneandSimple. all right reserved.</p>  	
    </div>-->
  </div>
        <script type="text/javascript">
		$(function(){
				$('.example-container > pre').each(function(i){
				eval($(this).text());
			});
		});
	</script>
</body>
</html>
