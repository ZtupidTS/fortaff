<html>
<head>
    <meta http-equiv=3D"Content-Type" content=3D"text/html; charset=3Dutf-8">
    <title>One and simple</title>
    <link rel=3D"stylesheet" type=3D"text/css" href=3D"http://lakeside.shift2d=
esign.com/assets/img/email/story-submission/screen.css">
</head>
<body>
<table width=3D"100%" border=3D"0" cellspacing=3D"0" cellpadding=3D"0" clas=
s=3D"bg1">
    <tr>
        <td align=3D"center">
            <table width=3D"600" border=3D"0" cellspacing=3D"0" cellpadding=3D"0" cl=
ass=3D"bg2">
                <tr>
                    <td class=3D"header" align=3D"left">
                        <img >
                    </td>
                </tr>
                <tr>
                    <td valign=3D"top" class=3D"body">
                        <table width=3D"100%" border=3D"0" cellspacing=3D"0" cellpadding=3D"0=
">
                            <tr>
                                <td valign=3D"top" class=3D"mainbar" align=3D"left">
                                    <h2>Oneandsimple</h2>
                                    <img 
>
                                    <p>From: <strong>gggg</strong><br />
                                    Email: <strong><a >gg</a></strong></p>
                                    <h3>Title:</h3>
                                    <p>ggg</p>
                                    <h3>Story:</h3>
                                    <p>ggg</p>
                                    <br>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                
            </table>
        </td>
    </tr>
</table>
</body>
</html>