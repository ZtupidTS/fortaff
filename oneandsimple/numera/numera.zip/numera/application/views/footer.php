  <?php if($this->session->userdata('loggedIn')) {?>
                    </div><!--<div class="section">-->
                </div> <!--<div class="main-contnt">--> 
                <div class="clear"></div>
            </div>
            <div class="footer">
                <p>2013 &#169; Numera, Powered by one and simple</p>
                <a href="#"><img src="images/oneandsimple-logo.png" alt="" /></a>
            </div>
            <div class="clear"></div>
        </div>
    <?php } ?>      
  
  <!--<div id="footermainPan">
    <div id="footerPan">
	  <p class="html"><?php echo anchor('admin','Admin');?></p>
		  <ul>
		  <li><a href="#">Home</a>|</li>
		  <li><a href="#">About</a> </li>
		  <?php if($this->session->userdata('loggedInAdmin')) {?>
		  <li>|<a href="<?php echo site_url()?>admin/changepassword">Change password</a>|</li>
		  <li><a href="<?php echo site_url()?>admin/editprofile">Edit My profile</a>|</li>
		  <li><a href="<?php echo site_url()?>admin/manageclient">Manage Client</a>|</li>
		  <li><a href="<?php echo site_url()?>admin/logout">Logout</a></li>
		  <?php } ?>
	   </ul>
	  <p class="copyright">�OneandSimple. all right reserved.</p>  	
    </div>-->
    
  </div>
</body>
</html>
