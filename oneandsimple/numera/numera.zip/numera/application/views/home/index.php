<?php $this->load->view('header')?>
<div id="bodytopmainPan">
<div id="bodytopPan">
	<h2>Welcome to One and simple Zone</h2>
	<p>
            <div id="dvHomeScreen" class="blockset" style="">
                <ul>
                    <li>
                        <div id="set_1">
                            <div class="block left">
                                <a href="javascript:void(0);" onclick="javascript:renderRecentDocs();"><span>
                                    Recent Docs</span></a></div>
                            <div class="block left">
                                <a href="javascript:void(0);" onclick="javascript:renderAllDocs();"><span>
                                    All Docs</span></a></div>
                            <div class="block left">
                                <a href="javascript:void(0);" onclick="javascript:renderSearchOptions();"><span>
                                    Search
                                </span></a>
                            </div>
                            
                            <div class="block left">
                                <a href="javascript:void(0);" onclick="renderAdministrationOptions();"><span>
                                    Admin</span></a></div>
                            
                            <div class="block disabled left">
                                <a href="javascript:void(0);"><span></span></a>
                            </div>
                            <div class="block disabled left">
                                <a href="javascript:void(0);"><span></span></a>
                            </div>
                            <div class="block disabled left">
                                <a href="javascript:void(0);"><span></span></a>
                            </div>
                            <div class="block disabled left">
                                <a href="javascript:void(0);"><span></span></a>
                            </div>
                            <div class="block disabled left">
                                <a href="javascript:void(0);"><span></span></a>
                            </div>
                            <div class="block disabled left">
                                <a href="javascript:void(0);"><span></span></a>
                            </div>
                            <div class="block disabled left">
                                <a href="javascript:void(0);"><span></span></a>
                            </div>
                            <div class="block disabled left">
                                <a href="javascript:void(0);"><span></span></a>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
		
        </p>	
</div>
</div>
<?php $this->load->view('footer')?>
