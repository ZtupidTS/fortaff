<?php $this->load->view('header')?>
<div class="login-page">
	<div class="login-logo"><a href="#"><img src="images/logo.png" alt="" /></a></div>
	<div class="login-form">
		<div class="login-top">Login Now</div>
		<div class="login-center">
			<?php $attributes = array('name' => 'login', 'id' => 'login');?>
			<?php echo form_open('admin',$attributes);?>
				<div>
					<div class="input-div">
						<span><img src="<?php echo base_url()?>images/user.png" alt="Username" /></span>
						<input placeholder="Username" type="text" name="username" id="username" class="required"/>
					</div>
					<?php echo form_error('username'); ?>
				</div>
				<div>	
					<div id="input-div" class="input-div"> <span><img src="<?php echo base_url()?>images/pass.png" alt="Password" /></span>
						<input placeholder="Password" type="password" class="required" name="password"/>
					</div>
					<?php echo form_error('password'); ?>
				</div>
				<div>
					<div class="input-radio">
						<input class="radio-input" name="chk_remember_me" type="radio" <?php if(get_cookie('user')!=""){ echo 'checked="checked"'; } ?> />
						<small>Remember Me</small>
						<input value="Sign-in" class="sign" type="submit" />
					</div>
				</div>
			<?php echo form_close();?>		
		</div>
	</div>
	<div class="forgot-pass">
	  <p>Forgot your password ? no worries, <a href="<?php echo base_url()?>">click here </a>to reset your password.</p>
	  <p class="foo-border">2013 &#169; umera, Powered by one and simple</p>
	</div>
</div>
<?php $this->load->view('footer')?>
