<div id="cabe�alho">
<img src="../images/header.jpg" alt="header"/> 
</div>