<?php
if($_SESSION['sexo_css'] == 'M')
{
	$css = "../css/estilo_rd.css";
}else{
	$css = "../css/estilo_rd_fem.css";
}
?>