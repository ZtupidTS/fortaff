<?php
switch($estrela)
{
case ($estrela <= 0.5);
	?>
	<img src="../images/estrela/meia_estrela.png" name="meia_estrela" alt="meia_estrela" title="meia_estrela"/>
	<?php
	break;
case (0.5<$estrela && $estrela <= 1);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<?php
	break;
case (1<$estrela && $estrela <= 1.5);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/meia_estrela.png" name="meia_estrela" alt="meia_estrela" title="meia_estrela"/>
	<?php
	break;
case (1.5<$estrela && $estrela <= 2);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<?php
	break;
case (2<$estrela && $estrela <= 2.5);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/meia_estrela.png" name="meia_estrela" alt="meia_estrela" title="meia_estrela"/>
	<?php
	break;
case (2.5<$estrela && $estrela <= 3);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<?php
	break;
case (3<$estrela && $estrela <= 3.5);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/meia_estrela.png" name="meia_estrela" alt="meia_estrela" title="meia_estrela"/>
	<?php
	break;
case (3.5<$estrela && $estrela <= 4);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<?php
	break;
case (4<$estrela && $estrela <= 4.5);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/meia_estrela.png" name="meia_estrela" alt="meia_estrela" title="meia_estrela"/>
	<?php
	break;

case (4.5<$estrela && $estrela <= 5);
	?>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<img src="../images/estrela/estrela.png" name="estrela" alt="estrela" title="estrela"/>
	<?php
	break;
}?>

