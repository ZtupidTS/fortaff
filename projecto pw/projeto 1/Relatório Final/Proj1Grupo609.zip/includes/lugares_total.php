<tr>
	<td>Capacidade:</td>
	<td>
	<input type="text" name="lugares_total" size="20" maxlength="30" value="<?= $_SESSION['lugares_total'];?>" onkeyup="this.value = LugaresTotal(this.value)" required class="form">
	</td>
</tr>