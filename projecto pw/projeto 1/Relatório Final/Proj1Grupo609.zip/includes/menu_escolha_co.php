<div id="menu_escolha">
<ul>
	<li><a href="delegacao_co.php">Delega��es</a></li>
	<li><a href="equipas_co.php">Equipas</a></li>
	<li><a href="atleta_co.php">Atletas</a></li>
	<li><a href="auxiliar_co.php">Auxiliares</a></li>
	<li><a href="modalidade_co.php">Modalidades</a></li>
	<li><a href="provas_co.php">Provas</a></li>
	<li><a href="eventos_co.php">Eventos</a></li>
	<div id"teste2">
	<li class="menu_terminar"><a href="../includes/el_dados_sessao.php" name="terminar" alt="Terminar Sess�o">Terminar Sess�o</a></li>
	</div>
</ul>
</div>

