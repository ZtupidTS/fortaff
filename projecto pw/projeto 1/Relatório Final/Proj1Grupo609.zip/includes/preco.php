<tr>
	<td>Pre�o:</td>
	<td>
	<input type="text" name="preco" id="preco" size="20" maxlength="30" value="<?= $_SESSION['preco'];?>" onkeyup="this.value = SoPreco(this.value)" required class="form">
	</td>
</tr>