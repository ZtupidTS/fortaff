<div id="rodap�">
<img src="../images/header_login.jpg" alt="Header" class="header_login"/>
<img src="../images/header.jpg" alt="Header" class="header_login2"/>
<div id="rodap�_centro">
<p> &#160 &#169 2011 JRE - Grupo 609 </p>
</div>
</div>