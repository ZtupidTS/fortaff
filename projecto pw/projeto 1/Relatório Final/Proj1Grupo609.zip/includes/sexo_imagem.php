<?php
if($dados['sexo'] == 'M')
{?>
	<img src="../images/sexo/sexo_masculino.png" class="bandeiras"/>
	<?php
}else{?>
	<img src="../images/sexo/sexo_feminino.png" class="bandeiras"/>
	<?php
}?>