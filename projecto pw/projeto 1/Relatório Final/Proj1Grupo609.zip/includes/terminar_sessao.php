
<a href="../includes/el_dados_sessao.php" name="terminar" alt="Terminar Sess�o" class="botao_terminar">Terminar Sess�o</a>


