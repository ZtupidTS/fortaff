function confirmacao(texto, url)
{
	alert(''+texto+'\nClique em ok para ser redireccionado');
	// window.location.href = "delegacao_co.php";
	window.location.href = ""+url;
}