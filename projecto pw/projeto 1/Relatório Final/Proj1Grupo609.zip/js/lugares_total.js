function LugaresTotal(lugares_total)
{
        return lugares_total.toString().replace(/[^0-9]/, "");
}