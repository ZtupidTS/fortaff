function MensagemPreco()
{
	alert('Inserir um pre�o valido, ex: 10.90');
}