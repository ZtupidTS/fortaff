function SoPreco(preco)
{
        return preco.toString().replace(/[^0-9.]/, "");
}
